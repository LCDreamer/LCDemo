//
//  BIDMembers.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-23.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDMembers.h"

@implementation BIDMembers
@synthesize membersId;
@synthesize membersName;
@end
