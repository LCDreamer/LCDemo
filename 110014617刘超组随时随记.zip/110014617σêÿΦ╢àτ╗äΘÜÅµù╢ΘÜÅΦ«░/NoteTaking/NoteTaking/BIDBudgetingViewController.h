//
//  BIDBudgetingViewController.h
//  NoteTaking
//
//  Created by zd2011 on 13-6-4.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDBudgetingViewController : UIViewController

@end
