//
//  timePickerView.h
//  timePicker
//
//  Created by LiuChao on 13-5-13.
//  Copyright (c) 2013年 刘超. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
#import "timePickerViewDelegate.h"
@interface timePickerView : UIControl
@property (retain, nonatomic) IBOutlet UIDatePicker *timePickerOutlet;
@property (retain, nonatomic) IBOutlet UILabel *titleLabelOutlet;
- (id)initWithTitle:(NSString *)title delegate:(id)delegate;
- (void)showInView:(UIView *)view;
- (IBAction)choose:(id)sender;
- (IBAction)sender:(id)sender;
@property (nonatomic, assign) id<timePickerViewDelegate> timeDelegate;
@property(strong,nonatomic) NSDate *selectedDate;
@property (retain, nonatomic) IBOutlet UILabel *titleLabel;
@end
