//
//  BIDBill.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-14.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BIDBill : NSObject
@property(assign,nonatomic)NSUInteger billId;//账单Id
@property(assign,nonatomic)NSUInteger billType;// 账单类型 Id
@property(assign,nonatomic)float amount;// 金额
@property(strong,nonatomic)NSDate*time;//时间
@property(strong,nonatomic)NSString*year;
@property(strong,nonatomic)NSString*moth;
@property(assign,nonatomic)NSUInteger typeId;//账单Id
@property(assign,nonatomic)NSUInteger subtypeId;// 账单类型 Id
@property(strong,nonatomic)NSString*type;//类型
@property(strong,nonatomic)NSString*subtype;//子类型
@property(strong,nonatomic)NSString*address;//地址

@property(strong,nonatomic)NSString*comment;//备注



@property(assign,nonatomic)NSUInteger membersId;//成员Id;
@property(strong,nonatomic)NSString*membersName;//成员名
@property(assign,nonatomic)float mothSpend;//月支出
@property(assign,nonatomic)float mothIncome;//月收入
@property(assign,nonatomic)float typeSpend;//类型支出
@property(assign,nonatomic)float typeIncome;//类型收入
@property(assign,nonatomic)float yearsSpend;//类型支出
@property(assign,nonatomic)float yearsIncome;//类型收入

@end
