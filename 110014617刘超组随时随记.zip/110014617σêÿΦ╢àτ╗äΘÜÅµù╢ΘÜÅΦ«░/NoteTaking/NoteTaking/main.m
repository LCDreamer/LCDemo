//
//  main.m
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "BIDAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([BIDAppDelegate class]));
    }
}
