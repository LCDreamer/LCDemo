//
//  BIDDatabaseManagement.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-14.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BIDBill.h"
#import "FMDatabase.h"
#define KMyDatabaseDatabase @"Database.sqlite"
#define kBillTabel @"BillList"
#define kTypeTable @"TypeList"
#define kBudgeTable @"BudgeList"
#define kMemBerTable @"MemBerList"
@interface BIDDatabaseManagement : NSObject
+(BIDDatabaseManagement*)sharedDatabaseManagement;
@property(strong,nonatomic)FMDatabase*database;
-(NSString*)dbPath:(NSString*)DatabaseName;
-(BOOL)saveBill:(BIDBill*)abill;
-(BOOL)saveTypeAandSubtype:(BIDBill*)atypeAandSubtype;
-(BOOL)saveMember:(BIDBill*)aMember;
-(NSMutableArray*)readMember;//读成员
-(NSMutableDictionary*)readTypeAandSubtype:(NSUInteger)typeKey;//读类型和子类型
-(NSDictionary*)readBillsForYear:(NSString*)year;//读每月月账单
-(NSDictionary*)readMothSpendingForYear:(NSString*)year;//读每月月支出
-(NSDictionary*)readMothIncomeForYear:(NSString*)year;//读每月月收入
-(NSDictionary*)readTypeOfPaymentForYear:(NSString*)year;//类型收支情况
-(NSDictionary*)readTypeSpendingForYear:(NSString*)year;//读类型支出
-(NSDictionary*)readTypeIncomeForYear:(NSString*)year;//读每类型收入
-(NSArray*)readMothsForYear:(NSString*)year;//读每一个月
-(NSArray*)readTypesForYear:(NSString*)year;//读每一种类型
-(NSString*)yearsOfIncomeForYear:(NSString*)year;//读年收入
-(NSString*)yearsOfSpendingForYear:(NSString*)year;//读年支出
-(NSMutableDictionary*)readTypeAandSubtypes;

/*－－－－－－－－－－－－－－－－－－－－－账单管理类函数－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－*/
@property(strong,nonatomic)NSMutableArray*subtypeArray;
@property(strong,nonatomic)NSMutableDictionary*dic;
@property(strong,nonatomic)NSMutableArray*billsArray;
@property(strong,nonatomic)NSMutableDictionary*billsDic;
@property(strong,nonatomic)NSMutableDictionary*MothSpendingDic;
@property(strong,nonatomic)NSMutableDictionary*MothIncomeDic;
@property(strong,nonatomic)NSMutableDictionary*typesDic;
@property(strong,nonatomic)NSMutableArray*typesArray;
@property(strong,nonatomic)NSMutableDictionary*typeSpendingDic;
@property(strong,nonatomic)NSMutableDictionary*typeIncomeDic;
@end
