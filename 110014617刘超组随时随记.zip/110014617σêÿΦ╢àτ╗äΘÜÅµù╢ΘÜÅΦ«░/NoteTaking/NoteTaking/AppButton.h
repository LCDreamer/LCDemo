//
//  AppButton.h
//  AppManage
//
//  Created by chen on 13-5-29.
//  Copyright (c) 2013年 chen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CAppButton : UIButton

+ (CAppButton*)BtnWithType:(UIButtonType)buttonType;

@end
