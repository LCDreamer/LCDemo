//
//  BIDTypeViewController.h
//  NoteTaking
//
//  Created by 刘超 on 13-5-6.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "HeadView.h"
@interface BIDTypeViewController : BIDBaseViewController<UITableViewDataSource,UITableViewDelegate,HeadViewDelegate>
{
    NSInteger _currentSection;
    NSInteger _currentRow;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic, retain) NSMutableArray* headViewArray;
@property(strong,nonatomic)NSDictionary*typesDic;
@property(strong,nonatomic)NSArray*typeArry;
@property(strong,nonatomic)NSString*typeKey;
@property(strong,nonatomic)NSMutableArray*typesArray;
@property (weak, nonatomic) IBOutlet UILabel *yearsIncomeOutle;
@property (weak, nonatomic) IBOutlet UILabel *yearsSpendOutlet;
@property (weak, nonatomic) IBOutlet UILabel *yearsbalanceOutle;
@property(strong,nonatomic)UILabel*yearLable;
@property(strong,nonatomic)NSString*year;
@property(strong,nonatomic)NSString*newaYear;
@property(strong,nonatomic)NSDictionary*typeIncomeDic;
@property(strong,nonatomic)NSDictionary*typeSpendingDic;
@end
