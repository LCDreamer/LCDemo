//
//  BIDBudgetManagement.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBudgetManagement.h"
#import "BIDDatabaseManagement.h"
@implementation BIDBudgetManagement
-(id)init{
    self=[super init];
    if (self) {
        BIDDatabaseManagement*Database=[BIDDatabaseManagement sharedDatabaseManagement];
        self.database=Database.database;
    }
    return self;
}
-(BOOL)saveMember:(BIDBudget*)aBudget{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (budgeAmount,budgeTime,budgetype) VALUES (%f,?,?)",kBudgeTable,aBudget.budgeAmount];
    YesOrNo=[self.database executeUpdate:sql,aBudget.budgeTime,aBudget.type];
    return YesOrNo;
}

/*-------------查类和子类-------------------*/

-(BOOL)isEqualToType:(NSString*)type ForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    BOOL YesOrNo=NO;
    NSString*sqlit=[NSString stringWithFormat:@"select budgetype from %@ where strftime('%%Y',budgeTime)=='%@' and strftime('%%m',budgeTime)=='%@' and budgetype='%@'",kBudgeTable,aYear,aMonth,type];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    while ([rs next]) {
        YesOrNo=YES;
    }
    return YesOrNo;
}
/*-------------修改类型---------------------*/

-(BOOL)modifyBudget:(BIDBudget*)aBudget{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"UPDATE %@ set budgeAmount=%f,budgeTime='%@' where budgetype='%@'",kBudgeTable,aBudget.budgeAmount,aBudget.budgeTime,aBudget.type];
    YesOrNo=[self.database executeUpdate:sql];
    
    return YesOrNo;
}
-(float)selectbudgeAmountForType:(NSString*)type andYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSString*sqlit=[NSString stringWithFormat:@"select budgeAmount from %@ where strftime('%%Y',budgeTime)=='%@' and strftime('%%m',budgeTime)=='%@' and budgetype='%@'",kBudgeTable,aYear,aMonth,type];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float abudgeAmount=0;
    while ([rs next]) {
        abudgeAmount=[[rs stringForColumn:@"budgeAmount"] floatValue];
    }
    return abudgeAmount;
}

//查找某月的支出,用于主页面刷新
-(float)selectMonthsBudgetSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSString*sqlit=[NSString stringWithFormat:@"select SUM(budgeAmount) AS aDayIncome from %@ where strftime('%%Y',budgeTime)=='%@' and strftime('%%m',budgeTime)=='%@'",kBudgeTable,aYear,aMonth];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float aDayIncome =0.0;
    while ([rs next]) {
        aDayIncome=[[rs stringForColumn:@"aDayIncome"] floatValue];
    }
    return aDayIncome;
}
@end
