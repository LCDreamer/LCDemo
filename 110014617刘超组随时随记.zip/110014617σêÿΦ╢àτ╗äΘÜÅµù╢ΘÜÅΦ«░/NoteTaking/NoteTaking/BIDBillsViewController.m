//
//  BIDBillsViewController.m
//  NoteTaking
//  账单控制器
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBillsViewController.h"
#import "BIDTimeViewController.h"
#import "BIDTypeViewController.h"
#import "BIDChartViewController.h"
#import "BIDnavigationController.h"
#import "BIDDetailBillViewController.h"

@interface BIDBillsViewController ()
-(void)loadViewController;
-(void)loadCustomTabBarView;
@end

@implementation BIDBillsViewController
@synthesize imagesArray;
@synthesize imagesHighArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.tabBar.hidden=YES;
        
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated]; 
    self.tabBar.hidden=YES;
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.tabBar.hidden=YES;
    
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadViewController];
    [self loadCustomTabBarView];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//初始化各个视图控制器
-(void)loadViewController
{
    BIDTimeViewController*VC1=[[BIDTimeViewController alloc]init];
    BIDnavigationController*homeNave=[[BIDnavigationController alloc]initWithRootViewController:VC1];
    
    UITabBarItem*homeItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:1];
    VC1.tabBarItem=homeItem;
    
    
    BIDTypeViewController*VC2=[[BIDTypeViewController alloc]init];
    BIDnavigationController*messageNave=[[BIDnavigationController alloc]initWithRootViewController:VC2];
    UITabBarItem*messageItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemContacts tag:2];
    VC2.tabBarItem=messageItem;
    
    
    BIDChartViewController*VC3=[[BIDChartViewController alloc]init];
    BIDnavigationController*trendsNave=[[BIDnavigationController alloc]initWithRootViewController:VC3];
    
    UITabBarItem*trendsItem=[[UITabBarItem alloc]initWithTitle:@"动态" image:[UIImage imageNamed:@"zhuti1"] tag:3];
    VC3.tabBarItem=trendsItem;
    NSArray*viewcontrollers=@[homeNave,messageNave,trendsNave];
    [self setViewControllers:viewcontrollers animated:YES];
}
//初始化TabBar
-(void)loadCustomTabBarView
{
    _tabBarBG=[[UIImageView alloc]initWithFrame:CGRectMake(0,20,320,49)];
    _tabBarBG.userInteractionEnabled=YES;
    _tabBarBG.image=[UIImage imageNamed:@"blue.jpg"];//filetab-bg.png
    [self.view addSubview:_tabBarBG];
    
    _selectview=[[UIImageView alloc]initWithFrame:CGRectMake(7, 49.0/2-45.0/2, 53, 45)];
    [_tabBarBG addSubview:_selectview];
    self.imagesArray=[[NSArray alloc]initWithObjects:@"shijian.jpg",@"leibie@2x",@"tubiao.jpg",@"duanxin.jpg",@"shezhi.jpg", nil];
    self.imagesHighArray=[[NSArray alloc]initWithObjects:@"shijian.jpg",@"leibie",@"tubiao",@"duanxin.jpg",@"shezhi.jpg", nil];
    _selectview.image=[UIImage imageNamed:@"blue.jpg"];
    float coordinateX=0;
    for (int index=0; index<3; index++) {
        UIButton*button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.tag=index;
        
        NSString*imageName=[NSString stringWithFormat:[imagesArray objectAtIndex:index]];
        NSString*imamgeHigName=[NSString stringWithFormat:[imagesHighArray objectAtIndex:index]];
        [button setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:imamgeHigName] forState:UIControlStateHighlighted];
        button.frame=CGRectMake(15+coordinateX, 49.0/2-20, 42, 40);
        [_tabBarBG addSubview:button];
        coordinateX+=110;
        [button addTarget:self action:@selector(changeViewController:) forControlEvents:UIControlEventTouchUpInside];
        BIDDetailBillViewController*detailBillView=[[BIDDetailBillViewController alloc]init];
        detailBillView._tabBar=_tabBarBG;
    }
}
-(void)changeViewController:(UIButton*)button
{
    self.selectedIndex=button.tag;
    [UIView beginAnimations:nil context:NULL];
    _selectview.frame=CGRectMake(7+button.tag*110, 49.0/2-45.0/2, 53, 45);
    [UIView commitAnimations];
}
-(void)showTabBar
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.34];
    _tabBarBG.frame=CGRectMake(0,20,320,49);
    [UIView commitAnimations];
}
-(void)hiddentTabBar
{
    [UIView beginAnimations:nil context:NULL];
    [UIView setAnimationDuration:0.35];
    _tabBarBG.frame=CGRectMake(-320,431,320,49);
    [UIView commitAnimations];
}
@end
