//
//  changeBackground.h
//  NoteTaking
//
//  Created by LC on 13-6-14.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface changeBackground : BIDBaseViewController
- (IBAction)fenglin:(id)sender;
- (IBAction)mantuoluo:(id)sender;
- (IBAction)caoyuan:(id)sender;
- (IBAction)muse:(id)sender;
- (IBAction)zhongguofeng:(id)sender;

@property (weak, nonatomic) IBOutlet UIButton *wanqiu;
@property (strong,nonatomic)NSString*imgName;

@property (strong,nonatomic)NSString *fenglin;
@property (strong,nonatomic)NSString *mantuoluo;
@property (strong,nonatomic)NSString *caodi;
@property (strong,nonatomic)NSString *muses;
@property (strong,nonatomic)NSString *zhongguofeng;

@end
