//
//  BIDSetViewController.h
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface BIDSetViewController : BIDBaseViewController
- (IBAction)setType:(id)sender;
- (IBAction)setMember:(id)sender;
- (IBAction)setChage:(id)sender;
- (IBAction)setDataBackup:(id)sender;
@end
