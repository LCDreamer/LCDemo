//
//  BIDSetSubTypeViewController.h
//  NoteTaking
//
//  Created by zd2011 on 13-6-19.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface BIDSetSubTypeViewController : BIDBaseViewController
@property(strong,nonatomic)NSMutableArray*subTypeArray;
@end
