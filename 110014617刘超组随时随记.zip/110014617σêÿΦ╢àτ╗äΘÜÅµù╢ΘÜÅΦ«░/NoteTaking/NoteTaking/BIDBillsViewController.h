//
//  BIDBillsViewController.h
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface BIDBillsViewController :UITabBarController{
    UIImageView*_selectview;
    UIImageView*_tabBarBG;
}
@property(strong,nonatomic)NSArray*imagesArray;
@property(strong,nonatomic)NSArray*imagesHighArray;
-(void)showTabBar;
-(void)hiddentTabBar;
@end
