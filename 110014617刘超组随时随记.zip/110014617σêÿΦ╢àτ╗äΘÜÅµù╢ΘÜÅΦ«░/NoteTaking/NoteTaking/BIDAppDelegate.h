//
//  BIDAppDelegate.h
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
//定义一个uiimage类型的全局变量，用来传送最新的背景图片
@property (strong, nonatomic) UIImage *backgroundImg;

@end
