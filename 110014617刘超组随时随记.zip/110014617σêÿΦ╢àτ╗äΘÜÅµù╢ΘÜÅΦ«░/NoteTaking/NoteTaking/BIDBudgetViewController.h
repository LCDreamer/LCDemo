//
//  BIDBudgetViewController.h
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "savBudgetDelegate.h"

@interface BIDBudgetViewController : BIDBaseViewController <savBudgetDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *scrollViewOutlet;
@property (weak, nonatomic) IBOutlet UILabel *allBudgetOutlet;
@property (weak, nonatomic) IBOutlet UILabel *SpendingOutlet;
@property (weak, nonatomic) IBOutlet UILabel *availableOutlet;

@end
