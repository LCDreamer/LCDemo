//
//  BIDType.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-23.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BIDType : NSObject
@property(assign,nonatomic)NSUInteger typeId;//账单Id
@property(assign,nonatomic)NSUInteger subtypeId;// 账单类型 Id
@property(strong,nonatomic)NSString*type;//类型
@property(strong,nonatomic)NSString*subtype;//子类型
@property(strong,nonatomic)NSString*address;//地址
@end
