//
//  pickerView.h
//  Picker
//
//  Created by LiuChao on 13-5-11.
//  Copyright (c) 2013年 刘超. All rights reserved.
//
#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>
#define KStateComponent  0
#define KzipComponent    1
#define kcount  
#import "pickerViewDelegate.h"
@interface pickerView : UIControl<UIPickerViewDataSource,UIPickerViewDelegate,pickerViewDelegate>
{
    NSArray*typeArray;
    NSArray*subtypeArray;
    
    
}
@property (retain, nonatomic) IBOutlet UIPickerView *PickerOutlet;
@property (retain, nonatomic) IBOutlet UILabel *titleLabelOutlet;
@property(strong,nonatomic)NSArray*typeArray;
@property(strong,nonatomic)NSArray*subtypeArray;
@property(strong,nonatomic)NSMutableArray*memberArray;
- (id)initWithTitle:(NSString *)title andTypeKey:(NSUInteger)typeKey delegate:(id)delegate;
- (void)showInView:(UIView *)view;

@property (retain, nonatomic) IBOutlet UILabel *titleLabel;
@property(strong,nonatomic)NSDictionary*dic;
- (IBAction)choose:(id)sender;
- (IBAction)cancel:(id)sender;
- (IBAction)edit:(id)sender;
@property (nonatomic, assign) id<pickerViewDelegate> typeDelegate;
@property(strong,nonatomic)NSString*pickerId;
@property(assign,nonatomic)NSInteger counts;
@property(strong,nonatomic)NSString*values;
@property(strong,nonatomic)id maindelegate;
@property(assign,nonatomic)NSUInteger typeKey;
@end
