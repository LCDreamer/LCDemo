//
//  BIDHomeViewController.h
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "DPMeterView.h"
@interface BIDHomeViewController : BIDBaseViewController
- (IBAction)PushToRememberView:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *yearsIncomeOutle;
@property (weak, nonatomic) IBOutlet UILabel *mothsIncomeOutle;
@property (weak, nonatomic) IBOutlet UILabel *dayIncomeOutle;
@property (weak, nonatomic) IBOutlet UILabel *yearsSpendOutlet;
@property (weak, nonatomic) IBOutlet UILabel *mothsSpendOutlet;
@property (weak, nonatomic) IBOutlet UILabel *daySpendOutlet;
@property (weak, nonatomic) IBOutlet UIButton *jiyibi;
@property (strong, nonatomic) IBOutlet DPMeterView *shape1View;
@property (strong, nonatomic) IBOutlet UILabel *allBudgetOutlet;
@property (strong, nonatomic) IBOutlet UILabel *SpendingOutlet;
@property (strong, nonatomic) IBOutlet UILabel *availableOutlet;
@property(assign,nonatomic) float ratio;
@end
