//
//  BIDAddTypeViewController.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-16.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "BIDBill.h"
@interface BIDAddTypeViewController : BIDBaseViewController
@property (weak, nonatomic) IBOutlet UITextField *typeOutlet;
@property(strong,nonatomic)BIDBill*atype;
- (IBAction)selecType:(id)sender;
@property (weak, nonatomic) IBOutlet UISegmentedControl *Segment;
@end
