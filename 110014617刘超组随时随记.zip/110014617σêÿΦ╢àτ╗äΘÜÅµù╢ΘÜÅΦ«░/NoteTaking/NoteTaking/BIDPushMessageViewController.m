//
//  BIDPushMessageViewController.m
//  NoteTaking
//  推送控制器
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDPushMessageViewController.h"
#import "NTChartView.h"
#import "BIDBillManagement.h"
@interface BIDPushMessageViewController ()

@end

@implementation BIDPushMessageViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"成员收支情况比较";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    self.menberNamesArray=[bill selectMembersNamesForYear:@"2013"];
    self.MembersIncomeArray=[bill selectMembersIncomeForYear:@"2013"];
    self.membersSpendingArray=[bill selectMembersSpendingForYear:@"2013"];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
   
    // Release any retained subviews of the main view.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    self.menberNamesArray=[bill selectMembersNamesForYear:@"2013"];
    self.MembersIncomeArray=[bill selectMembersIncomeForYear:@"2013"];
    self.membersSpendingArray=[bill selectMembersSpendingForYear:@"2013"];
    int px, py;
    
    
    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad){
        
        if ( self.interfaceOrientation == UIDeviceOrientationLandscapeLeft || self.interfaceOrientation == UIDeviceOrientationLandscapeRight)
        {
            px = 1024;
            py = 768-20;
        }
        else
        {
            px = 768; //tweaked, should be better
            py = 1024-20;
        }
        
        
    }else {
        
        if ( self.interfaceOrientation == UIDeviceOrientationLandscapeLeft || self.interfaceOrientation == UIDeviceOrientationLandscapeRight)
        {
            px = 480;
            py = 320-20;
        }
        else
        {
            px = 320; //tweaked, should be better
            py = 480-20;
        }
    }
    
    NTChartView *v = [[NTChartView alloc] initWithFrame:CGRectMake(0, 0, px, py-98)];
	
	NSArray *g1 = self.MembersIncomeArray;
    
    NSArray *g2 =self.membersSpendingArray;
    
    NSArray *g = [NSArray arrayWithObjects:g1, g2, nil];
    
    NSArray *gt = [NSArray arrayWithObjects:@"收入",@"支出", nil];
    NSArray *xL = self.menberNamesArray;
    NSArray *ct = [NSArray arrayWithObjects:@"支出对比",@"", nil];
    
	v.groupData = g;
    v.groupTitle = gt;
    v.xAxisLabel = xL;
    v.chartTitle = ct;
	
    v.backgroundColor = [UIColor clearColor];
    
    v.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    self.scrollView.contentSize=CGSizeMake(self.scrollView.frame.size.width*2,self.scrollView.frame.size.height);
    //[self.view addSubview:v];
    [self.scrollView addSubview:v];

}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    
    return YES;
}


@end
