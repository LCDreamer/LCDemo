//
//  BIDBill.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-14.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBill.h"

@implementation BIDBill
@synthesize billId;
@synthesize billType;
@synthesize amount;
@synthesize time;
@synthesize typeId;
@synthesize subtypeId;
@synthesize type;
@synthesize subtype;
@synthesize address;
@synthesize comment;
@synthesize membersId;
@synthesize membersName;
@synthesize year;
@synthesize moth;
@synthesize mothSpend;
@synthesize mothIncome;
@synthesize typeSpend;
@synthesize typeIncome;
@synthesize yearsSpend;
@synthesize yearsIncome;
@end
