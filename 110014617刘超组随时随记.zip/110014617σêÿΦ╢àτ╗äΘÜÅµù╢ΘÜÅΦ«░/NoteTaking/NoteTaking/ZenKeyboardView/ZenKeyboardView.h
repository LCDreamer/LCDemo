//
//  ZenKeyboardView.h
//  ZenKeyboard
//
//  Created by Kevin Nick on 2012-11-9.
//  Copyright (c) 2012年 com.zen. All rights reserved.
//

#import <UIKit/UIKit.h>

#define KeyboardNumericKeyWidth 108
#define KeyboardNumericKeyHeight 53

@protocol ZenKeyboardViewDelegate <NSObject>
@optional
-(void)didNumericKeyPressed:(UIButton *)button;
-(void)didBackspaceKeyPressed;
-(void)closeTheKeyboard;//关闭键盘
-(void)accordingTospendingModule;//显示支出入模块
-(void)accordingToIncomeModule;//显示收入模块
@end

@interface ZenKeyboardView : UIView

@property(nonatomic, assign) id<ZenKeyboardViewDelegate> delegate;

@end
