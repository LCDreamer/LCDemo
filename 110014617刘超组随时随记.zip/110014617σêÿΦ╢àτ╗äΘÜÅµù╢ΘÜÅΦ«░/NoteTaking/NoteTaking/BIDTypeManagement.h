//
//  BIDTypeManagement.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "BIDType.h"
@interface BIDTypeManagement : NSObject
@property(strong,nonatomic)FMDatabase*database;

/*-------------增加类和子类-------------------*/

-(BOOL)saveTypeAandSubtype:(BIDType*)atypeAandSubtype;

/*-------------查类和子类-------------------*/
-(NSDictionary*)readTypeAandSubtype;//读类型和子类型

/*-------------修改类型---------------------*/
//修改类型
-(BOOL)modifytype:(BIDType*)atype;

//修改子类型
-(BOOL)modifySubType:(BIDType*)subtype;
/*-------------删除类型----------------------*/

//删除类型
-(BOOL)deletetype:(NSString*)atype;

//删除子类型
-(BOOL)deleteSubType:(NSString*)subtype;
@end
