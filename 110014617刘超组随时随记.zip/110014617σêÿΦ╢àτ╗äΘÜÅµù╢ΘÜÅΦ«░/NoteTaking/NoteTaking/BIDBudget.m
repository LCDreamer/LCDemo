//
//  BIDBudget.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-23.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBudget.h"

@implementation BIDBudget
@synthesize budgeAmount;
@synthesize budgeTime;
@synthesize budgeId;
@synthesize typeId;
@synthesize subtypeId;
@synthesize type;
@synthesize subtype;
@synthesize restAmount;
@end
