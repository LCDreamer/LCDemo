//
//  BIDSetViewController.m
//  NoteTaking
//  设置控制器
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDSetViewController.h"
#import "BIDSetTypesViewController.h"
#import "BIDSetMemberViewController.h"
#import "changeBackground.h"
#import "BIDAppDelegate.h"
#import "ViewController.h"
@interface BIDSetViewController ()

@end

@implementation BIDSetViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"设置";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)setType:(id)sender {
//    点击按钮视图将跳转到BIDSetTypesViewController控制的视图下
    BIDSetTypesViewController*setTypesViewController=[[BIDSetTypesViewController alloc]init];
    [self.navigationController pushViewController:setTypesViewController animated:YES];
}

- (IBAction)setMember:(id)sender {
//    点击按钮视图将跳转到BIDSetMemberViewController控制的视图下
    BIDSetMemberViewController*setMemberViewController=[[BIDSetMemberViewController alloc]init];
    [self.navigationController pushViewController:setMemberViewController animated:YES];
}

- (IBAction)setChage:(id)sender {
    changeBackground *change = [[changeBackground alloc]init];
    [self.navigationController pushViewController:change animated:YES];
}

- (IBAction)setDataBackup:(id)sender {
    ViewController*view=[[ViewController alloc]initWithNibName:@"ViewController_iPhone" bundle:nil];
    [self.navigationController pushViewController:view animated:YES];
}
@end
