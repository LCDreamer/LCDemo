//
//  BIDMainViewController.h
//  Message
//
//  Created by 刘超 on 13-4-13.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface BIDMainViewController : UITabBarController{
    UIImageView*_selectview;
    UIImageView*_tabBarBG;
}
@property(strong,nonatomic)NSArray*imagesArray;
@property(strong,nonatomic)NSArray*imagesHighArray;
-(void)showTabBar;
-(void)hiddentTabBar;

@end
