//
//  BIDTimeViewController.h
//  NoteTaking
//  按时间查询试图控制器
//  Created by 刘超 on 13-5-6.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "HeadView.h"
@interface BIDTimeViewController : BIDBaseViewController<UITableViewDataSource,UITableViewDelegate,HeadViewDelegate>
{
    NSInteger _currentSection;
    NSInteger _currentRow;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property(nonatomic, retain) NSMutableArray* headViewArray;
@property(strong,nonatomic)NSArray*mothArry;
@property(strong,nonatomic)NSString*mothKey;
@property(strong,nonatomic)NSMutableArray*billsArray;
@property (weak, nonatomic) IBOutlet UILabel *yearsIncomeOutle;
@property (weak, nonatomic) IBOutlet UILabel *yearsSpendOutlet;
@property (weak, nonatomic) IBOutlet UILabel *yearsbalanceOutle;
@property(strong,nonatomic)UILabel*yearLable;
@property(strong,nonatomic)NSString*year;
@property(strong,nonatomic)NSString*newaYear;
@property(strong,nonatomic)NSDictionary*mothIncomeDic;
@property(strong,nonatomic)NSDictionary*mothSpendingDic;
@end
