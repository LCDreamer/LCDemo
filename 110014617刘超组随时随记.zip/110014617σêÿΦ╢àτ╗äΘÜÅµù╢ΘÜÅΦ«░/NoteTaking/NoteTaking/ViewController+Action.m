//
//  ViewController+Action.m
//  KuaiPanOpenAPIDemo
//
//  Created by Jinbo He on 12-7-20.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"
#import "BIDDatabaseManagement.h"
@implementation ViewController (Action)


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (authController.isAlreadAuth) {
        NSLog(@"已经登录。。。。");
    }
    else {
        NSLog(@"还没有登录。。。。");
    }
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

#pragma mark - Handle events

- (IBAction)doAuthorize:(id)sender
{
    UIButton *auth = (UIButton *)sender;
    
    KPConsumer *consumer = [[KPConsumer alloc] initWithKey:@"xcInFxiv9tnMmS5a" secret:@"D7JvQn0wTR5rP9D9"];
    authController = [[KPAuthController alloc] initWithConsumer:consumer];
    
    if ([auth.titleLabel.text isEqualToString:@"认证方式一"]) {
        //进行导航推出授权页面
        [self.navigationController pushViewController:authController animated:YES];
        
    }else if ([auth.titleLabel.text isEqualToString:@"认证方式二"]){
        //进行present页面
        [self presentViewController:authController animated:YES completion:NULL];
    }
    
    //[consumer release];
    
}

- (IBAction)doExit:(id)sender
{
    if (authController) {
        [authController clearAuthInfo];
    }
}

- (IBAction)doGetUserInfo:(id)sender
{
    _getUserInfoOp = [[KPGetUserInfoOperation alloc] initWithDelegate:self operationItem:nil];
    
    [_getUserInfoOp executeOperation];
}

- (IBAction)doCreateFolder:(id)sender
{
    KPFolderOperationItem *item = [[KPFolderOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"KPTest/KPTestFolder";
    
    _createFolderOp = [[KPCreateFolderOperation alloc] initWithDelegate:self operationItem:item];
    [_createFolderOp executeOperation];
    
    //[item release];
}

- (NSString *)urlEncodeCovertString:(NSString *)source
{
    if (source==nil) {
        return @"";
    }
    
    NSMutableString *result = [NSMutableString string];
	const char *p = [source UTF8String];
	
	for(unsigned char c; (c = *p); p++) {
        
		switch(c) {
			case '0' ... '9':
			case 'A' ... 'Z':
			case 'a' ... 'z':
			case '.':
			case '-':
			case '~':
			case '_':
				[result appendFormat:@"%c", c];
				break;
			default:
				[result appendFormat:@"%%%02X", c];
		}
	}

	return result;
}

- (IBAction)doGetDirectoryInfo:(id)sender
{
    KPGetDirectoryOperationItem *item = [[KPGetDirectoryOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"iPad备份相册";//@"我的音乐";
    
    item.filterExt = @"jpg,png";
    item.sortType = kSortByTime;
//    item.sortType = kSortBySize;
    
    _getDirectoryOp = [[KPGetDirectoryOperation alloc] initWithDelegate:self operationItem:item];
    [_getDirectoryOp executeOperation];
    
    //[item release];
}

- (IBAction)doUploadFile:(id)sender
{
    [_activity startAnimating];
    _progress.hidden = NO;
    _progress.progress = 0.0;
    
    KPUploadFileOperationItem *item = [[KPUploadFileOperationItem alloc] init];
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    NSString*file=[databaseManagement dbPath:KMyDatabaseDatabase];
//   NSString *filepath = [[NSBundle mainBundle] pathForResource:@"Database" ofType:@"sqlite"];
    
    item.root = @"app_folder";
    
    //要上传到的文件夹必须已经创建，即hejinbo123文件夹必须已经存在,并且必须携带文件名
    item.path =@"Database.sqlite"; //@"KPTest/KPTestFolder/KPTestFile.jpg";
    item.fileName = @"Database.sqlite";
    item.fileData = [NSData dataWithContentsOfFile:file];
    item.isOverwrite = YES;
    
    _uploadFileOp = [[KPUploadFileOperation alloc] initWithDelegate:self operationItem:item];
    [_uploadFileOp executeOperation];
    
    //[item release];
}

- (IBAction)doUploadStop:(id)sender
{
    [_uploadFileOp cancelOperation];
    //[_uploadFileOp release];
    _uploadFileOp = nil;
}

- (IBAction)doDownloadStop:(id)sender
{
    [_downloadFileOp cancelOperation];
    //[_downloadFileOp release];
    _downloadFileOp = nil;
}

- (IBAction)doDownloadFile:(id)sender
{
    [_activity startAnimating];
    _progress.hidden = NO;
    _progress.progress = 0.0;
    
    KPFolderOperationItem *item = [[KPFolderOperationItem alloc] init];
   // BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
   // NSString*file=[databaseManagement dbPath:KMyDatabaseDatabase];
    item.root = @"app_folder";
    //要下载的文件相对路径,并且必须携带文件名
    item.path = @"Database.sqlite";
    
    _downloadFileOp = [[KPDownloadFileOperation alloc] initWithDelegate:self operationItem:item];
    [_downloadFileOp executeOperation];
    
    //[item release];
}

-(IBAction)doDeleteFile:(id)sender
{
    KPFolderOperationItem *item = [[KPFolderOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"KPTest/KPDeleteFolder/KPDeleteFile.jpg";
    
    _deleteOp = [[KPDeleteOperation alloc] initWithDelegate:self operationItem:item];
    
    [_deleteOp executeOperation];
    
    //[item release];
}

-(IBAction)doDeleteFolder:(id)sender
{
    KPFolderOperationItem *item = [[KPFolderOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"KPTest/KPDeleteFolder";
    
    _deleteOp = [[KPDeleteOperation alloc] initWithDelegate:self operationItem:item];
    
    [_deleteOp executeOperation];
    
    //[item release];
}

-(IBAction)doMoveFile:(id)sender
{
    
    KPMoveOperationItem *item = [[KPMoveOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.fromPath = @"KPTest/KPMoveSourceFile.jpg";
    item.toPath = @"KPTest/KPMoveTargetFile.jpg";
    
    _moveOp = [[KPMoveOperation alloc] initWithDelegate:self operationItem:item];
    
    [_moveOp executeOperation];
    
    //[item release];
}

-(IBAction)doMoveFolder:(id)sender
{
    KPMoveOperationItem *item = [[KPMoveOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.fromPath = @"KPTest/KPMoveSourceFolder";
    item.toPath = @"KPTest/KPMoveTargetFolder";
    
    _moveOp = [[KPMoveOperation alloc] initWithDelegate:self operationItem:item];
    
    [_moveOp executeOperation];
    
    //[item release];
}

- (IBAction)doCopyFile:(id)sender
{
    KPCopyOperationItem *item = [[KPCopyOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.fromPath = @"KPTest/KPCopySourceFile.jpg";
    item.toPath = @"KPTest/KPCopyTargetFile.jpg";
    
    _copyOp = [[KPCopyOperation alloc] initWithDelegate:self operationItem:item];
    
    [_copyOp executeOperation];
    
   // [item release];
}

- (IBAction)doCopyFolder:(id)sender
{
    KPCopyOperationItem *item = [[KPCopyOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.fromPath = @"KPTest/KPCopySourceFolder";
    item.toPath = @"KPTest/KPCopyTargetFolder";
    
    _copyOp = [[KPCopyOperation alloc] initWithDelegate:self operationItem:item];
    [_copyOp executeOperation];
    
    //[item release];
}

- (IBAction)doShareFile:(id)sender
{
    KPGetShareLinkOperationItem *item = [[KPGetShareLinkOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.name = @"123";
    item.accessCode = @"123";
    item.path = @"我的照片/2012-04-20 11.11.56_568.jpg";
    
    _shareFileOp = [[KPGetShareLinkOperation alloc] initWithDelegate:self operationItem:item];
    [_shareFileOp executeOperation];
    
    //[item release];
}

- (IBAction)doCopyRefFile:(id)sender
{
    KPCopyOperationItem *item = [[KPCopyOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.Path = @"KPTest/KPCopyRefFile.jpg";
    
    _copyRefFileOp = [[KPCopyRefOperation alloc] initWithDelegate:self operationItem:item];
    
    [_copyRefFileOp executeOperation];
    
    //[item release];
}

- (IBAction)doCopyRefFolder:(id)sender
{
    KPCopyOperationItem *item = [[KPCopyOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.Path = @"KPTest/KPCopyRefFolder";
    
    _copyRefFileOp = [[KPCopyRefOperation alloc] initWithDelegate:self operationItem:item];
    
    [_copyRefFileOp executeOperation];
    
    //[item release];
}

- (IBAction)doThumbnail:(id)sender
{
    KPThumbnailOperationItem *item = [[KPThumbnailOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"KPTest/KPTestFolder/KPTestFile.jpg";
    item.height = 123;
    item.width = 123;
    
    _thumbnailOp = [[KPThumbnailOperation alloc] initWithDelegate:self operationItem:item];
    [_thumbnailOp executeOperation];
    
    //[item release];
}

- (IBAction)doDocumentView:(id)sender
{
    [_activity startAnimating];
    _progress.hidden = NO;
    _progress.progress = 0.0;
    
    KPDocumentConvertOperationItem *item = [[KPDocumentConvertOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"KPTest/KPDocumentConvert.pdf";
    item.documentType = kDocumentPDF;
    item.viewFormat = kViewiPad;
    item.compressType = kCompressNone;
    
    _documentConvertOp = [[KPDocumentConvertOperation alloc] initWithDelegate:self operationItem:item];
    [_documentConvertOp executeOperation];
    
    //[item release];
}

- (IBAction)doFileHistory:(id)sender
{
    KPFolderOperationItem *item = [[KPFolderOperationItem alloc] init];
    
    item.root = @"app_folder";
    item.path = @"KPTest/KPHistory.doc";
    
    _historyOP = [[KPGetFileHistoryOperation alloc] initWithDelegate:self operationItem:item];
    [_historyOP executeOperation];
    
    //[item release];
}

@end
