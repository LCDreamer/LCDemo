//
//  BIDRememberViewController.m
//  NoteTaking
//  记一笔试图控制器
//  Created by LiuChao on 13-5-9.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDRememberViewController.h"
#import "pickerView.h"
#import "timePickerView.h"
#import "BIDDatabaseManagement.h"
#import "BIDBillManagement.h"
#import "FPNumberPadView.h"
#import "BIDBillsViewController.h"
#import "changeBackground.h"
@interface BIDRememberViewController ()

@end

@implementation BIDRememberViewController
@synthesize typeId;
@synthesize abiil;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    if (self.yesOrNo==YES) {
        [self showTypeOfbutton];
        [self setZenKeyboardView];
        [self setUIBarButtonItem];
        self.typeOutlet.delegate=self;
        self.commentOutlet.delegate=self;
    }
    if (self.yesOrNo==NO) {
        BIDBillsViewController*tabBarController=(BIDBillsViewController*)self.tabBarController;
        [tabBarController hiddentTabBar];
        [self setZenKeyboardView];
        [self setModifButtonItem];
        self.saveBillOutlet.hidden=YES;
        self.toWriteOutlet.hidden=YES;
        self.title=@"详细账单";
        [self showDetailedBill];
    }
    self.typeId=1;
    self.isOpenTypePiker=YES;
    self.isOpenMenberPiker=YES;
    self.isOpenTimePiker=YES;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [_amountOutlet becomeFirstResponder];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewDidUnload {
    [self setTypeNameOutlet:nil];
    [self setTemplateTypeImageOutlet:nil];
    [super viewDidUnload];
}
#pragma mark - setUIBarButtonItem
-(void)setUIBarButtonItem{//初始化右边的保存按钮
    UIBarButtonItem*leftItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemOrganize target:self action:@selector(SaveTheBill:)];
    self.navigationItem.rightBarButtonItem=leftItem;
}
-(void)setModifButtonItem{//初始化右边的保存按钮
    UIBarButtonItem*leftItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemOrganize target:self action:@selector(modifTheBill)];
    self.navigationItem.rightBarButtonItem=leftItem;
}

#pragma mark - SINavigationMenuDelegate
- (void)didSelectItemAtIndex:(NSUInteger)index
{
    NSLog(@"did selected item at index %d", index);
}
-(void)shwoTemplateTypeName:(NSString *)templateTypeName//显示模块名
{
    self.typeNameOutlet.text=templateTypeName;
}
-(void)shwoTemplateTypeImage:(NSString *)templateTypeImage//显示模板图片
{
    self.templateTypeImageOutlet.image=[UIImage imageNamed:templateTypeImage];
}
-(void)showTypeOfbutton//初始化模板下拉菜单
{
    if (self.navigationItem) {
        CGRect frame = CGRectMake(0.0, 0.0, 200.0, self.navigationController.navigationBar.bounds.size.height);
        SINavigationMenuView *menu = [[SINavigationMenuView alloc] initWithFrame:frame title:@"选择模板"];
        [menu displayMenuInView:self.view];
        menu.items = @[@"支出模板", @"收入模板", @"借款模板", @"贷款模板",];
        menu.delegate = self;
        self.navigationItem.titleView = menu;
    }
}


- (void)setZenKeyboardView {//初始化数字键盘
    FPNumberPadView *numberPadView = [[FPNumberPadView alloc] initWithFrame:CGRectMake(0, 0, 320, 256)];
    numberPadView.savdelegate=self;
    numberPadView.saveOutlet.hidden=YES;
    numberPadView.textField =_amountOutlet;
}

//-----------第一个自定义键盘的协议方法---------------
#pragma mark - ZenKeyboardViewDelegate


- (void)didNumericKeyPressed:(UIButton *)button {//显示数字小数
    self.amountOutlet.text = [NSString stringWithFormat:@"%@%@", self.amountOutlet.text, button.titleLabel.text];
}

- (void)didBackspaceKeyPressed {//退格功能
    NSInteger length = _amountOutlet.text.length;
    if (length == 0) {
       _amountOutlet.text = @"";
        
        return;
    }
    NSString *substring = [_amountOutlet.text substringWithRange:NSMakeRange(0, length - 1)];
    _amountOutlet.text = substring;
}
-(void)closeTheKeyboard//关闭键盘
{
    [self.amountOutlet resignFirstResponder];
}
-(void)accordingToIncomeModule{//显示收入模块
    self.typeNameOutlet.text=@"收入:";
    self.templateTypeImageOutlet.image=[UIImage imageNamed:@"income.png"];
    self.typeId=0;
}
-(void)accordingTospendingModule//显示支出入模块
{
    self.typeNameOutlet.text=@"支出:";
    self.templateTypeImageOutlet.image=[UIImage imageNamed:@"spending.png"];
    self.typeId=1;
}
//--------------------保存一笔账---------------------------------


- (IBAction)SaveTheBill:(id)sender {//保存账单
   
    NSArray*typeArray=[self.typeOutlet.text componentsSeparatedByString:@">>"];
    NSArray*timeArray=[self.timeOutlet.text componentsSeparatedByString:@"-"];
     NSArray*dateAarry=[self.timeOutlet.text componentsSeparatedByString:@"+"];
    BIDBill*aBill=[[BIDBill alloc]init];
    aBill.amount=[self.amountOutlet.text floatValue];
    if ([typeArray count]==1||[timeArray count]==1||[dateAarry count]==1) {
        UIAlertView *alters = [[UIAlertView alloc] initWithTitle:@"提示" message:@"记账类型、成员、时间不能不填哟，记账失败" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alters show];
    }else{
        aBill.type=[typeArray objectAtIndex:0];
        aBill.subtype=[typeArray objectAtIndex:1];
        aBill.time=[dateAarry objectAtIndex:0];
        aBill.year=[timeArray objectAtIndex:0];
        aBill.moth=[timeArray objectAtIndex:1];
    }
    aBill.typeId=self.typeId;
    aBill.membersName=self.membersOutlet.text;
    aBill.comment=self.commentOutlet.text;
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    if ([typeArray count]!=1 &&[timeArray count]!=1 &&[dateAarry count]!=1) {
        [databaseManagement saveBill:aBill];
        
        UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"保存成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        
        [alter show];
    }
    
    
}
-(void)modifTheBill{
    BIDBill*newBill=[[BIDBill alloc]init];
    NSArray*typeArray=[self.typeOutlet.text componentsSeparatedByString:@">>"];
    NSArray*timeArray=[self.timeOutlet.text componentsSeparatedByString:@"-"];
    NSArray*dateAarry=[self.timeOutlet.text componentsSeparatedByString:@"+"];
    newBill.amount=[self.amountOutlet.text floatValue];
    newBill.type=[typeArray objectAtIndex:0];
    newBill.subtype=[typeArray objectAtIndex:1];
    newBill.typeId=self.abiil.typeId;
    newBill.billId=self.abiil.billId;
    newBill.membersName=self.membersOutlet.text;
    newBill.time=[dateAarry objectAtIndex:0];
    newBill.year=[timeArray objectAtIndex:0];
    newBill.moth=[timeArray objectAtIndex:1];
    newBill.comment=self.commentOutlet.text;
    BIDBillManagement*billManagement=[[BIDBillManagement alloc]init];
    [billManagement modificationaBill:newBill];
    
}
- (IBAction)toWriteaBill:(id)sender {//再记一笔
    self.amountOutlet.text=nil;
    self.typeOutlet.text=nil;
    self.membersOutlet.text=nil;
    self.timeOutlet.text=nil;
    self.commentOutlet.text=nil;
    self.isOpenMenberPiker=YES;
    self.isOpenTimePiker=YES;
    self.isOpenTypePiker=YES;
}

#pragma mark - pickerViewDelegate
//显示类型协议的实现
-(void)typeSelection:(NSString *)type Aadsubtype:(NSString *)subtype
{
    self.typeOutlet.text=[[NSString alloc]initWithFormat:@"%@>>%@",type,subtype ];
    self.isOpenTypePiker=YES;
}
-(void)isOpenPicker{
    self.isOpenTypePiker=YES;
    self.isOpenMenberPiker=YES;
    self.isOpenTimePiker=YES;
}

//显示成员协议的实现
-(void)memberSelection:(NSString *)member
{
    self.membersOutlet.text=[[NSString alloc]initWithFormat:@"%@",member];
    self.isOpenMenberPiker=YES;
}
-(void)timeSelection:(NSString *)time
{
    self.timeOutlet.text=[[NSString alloc]initWithFormat:@"%@",time];
    self.isOpenTimePiker=YES;
    
    
}
//文本框协议的的实现
-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return NO;
}

- (IBAction)showTypePikerView:(id)sender {//显示类型选取器
    [self.amountOutlet resignFirstResponder];
    if (self.isOpenTypePiker==YES) {
        self.typeOutlet.delegate=self;
        pickerView *locateView = [[pickerView alloc] initWithTitle:@"选择类型"  andTypeKey:self.typeId delegate:self];
        locateView.typeKey=self.typeId;
        [locateView showInView:self.view];
        self.isOpenTypePiker=NO;
        self.isOpenMenberPiker=YES;
        self.isOpenMenberPiker=YES;
    }
}

- (IBAction)showMembersPikerView:(id)sender {//显示成员选取器的
    if (self.isOpenMenberPiker==YES) {
        self.membersOutlet.delegate=self;
        pickerView *locateView = [[pickerView alloc] initWithTitle:@"选择成员" andTypeKey:self.typeId delegate:self];
        [locateView showInView:self.view];
        self.isOpenMenberPiker=NO;
        self.isOpenTypePiker=YES;
        self.isOpenTimePiker=YES;
    }
    
}
#pragma mark - pickerViewDelegate
- (IBAction)showTimePikerView:(id)sender {
    if (self.isOpenTimePiker==YES) {
        self.timeOutlet.delegate=self;
        timePickerView *locateView = [[timePickerView alloc] initWithTitle:@"选择时间" delegate:self];
        [locateView showInView:self.view];
        self.isOpenTimePiker=NO;
        self.isOpenTypePiker=YES;
        self.isOpenMenberPiker=YES;
    }
    
}
-(void)isOpenTimePikerView{
    self.isOpenTypePiker=YES;
    self.isOpenMenberPiker=YES;
    self.isOpenTimePiker=YES;
}
-(void)GotoSetView{
    self.tabBarController.selectedIndex=4;
}
//------------------------第二个数字键盘的协议方法-----------------
#pragma mark - savBudgetDelegate
-(void)accordingspendingModule{//显示支出入模块
    self.typeNameOutlet.text=@"支出:";
    self.templateTypeImageOutlet.image=[UIImage imageNamed:@"spending.png"];
    self.typeId=1;
}
-(void)accordingIncomeModule{//显示收入模块
    self.typeNameOutlet.text=@"收入:";
    self.templateTypeImageOutlet.image=[UIImage imageNamed:@"income.png"];
    self.typeId=0;
}
-(void)showDetailedBill{
    if (self.abiil.billType==0) {
        self.typeNameOutlet.text=@"收入:";
        self.templateTypeImageOutlet.image=[UIImage imageNamed:@"income.png"];
    }else{
        self.typeNameOutlet.text=@"支出:";
        self.templateTypeImageOutlet.image=[UIImage imageNamed:@"spending.png"];
    }
    NSString*amount=[NSString stringWithFormat:@"%0.2f",self.abiil.amount];
    self.self.amountOutlet.text=amount;
    NSString*type=[NSString stringWithFormat:@"%@>>%@",self.abiil.type,self.abiil.subtype];
    self.typeOutlet.text=type;
    self.membersOutlet.text=self.abiil.membersName;
    NSString*time=[NSString stringWithFormat:@"%@",self.abiil.time];
    self.timeOutlet.text=time;
    self.commentOutlet.text=self.abiil.comment;
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    if ([text isEqualToString:@"\n"])
    {
        [self.commentOutlet resignFirstResponder];
        NSTimeInterval animationDuration = 0.30f;
        CGRect frame = self.view.frame;
        frame.origin.y +=180;
        frame.size. height -=180;
        self.view.frame = frame;
        //self.view移回原位置
        [UIView beginAnimations:@"ResizeView" context:nil];
        [UIView setAnimationDuration:animationDuration];
        self.view.frame = frame;
        [UIView commitAnimations];
        return NO;
    }
    
    return YES; 
}
-(void)textViewDidBeginEditing:(UITextView *)textView{
    NSTimeInterval animationDuration = 0.30f;
    CGRect frame = self.view.frame;
    frame.origin.y -=180;
    frame.size.height +=180;
    self.view.frame = frame;
    [UIView beginAnimations:@"ResizeView" context:nil];
    [UIView setAnimationDuration:animationDuration];
    self.view.frame = frame;
    [UIView commitAnimations];
}

@end
