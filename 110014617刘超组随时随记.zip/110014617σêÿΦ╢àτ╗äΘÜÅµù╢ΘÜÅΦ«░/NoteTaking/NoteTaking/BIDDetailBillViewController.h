//
//  BIDDetailBillViewController.h
//  NoteTaking
//
//  Created by LiuChao on 13-5-17.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDDetailBillViewController : UIViewController
@property(strong,nonatomic)UIImageView*_tabBar;
@end
