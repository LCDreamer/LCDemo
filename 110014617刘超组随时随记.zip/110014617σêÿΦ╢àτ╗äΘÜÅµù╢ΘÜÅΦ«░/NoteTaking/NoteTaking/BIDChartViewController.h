//
//  BIDChartViewController.h
//  NoteTaking
//  按图表统计视图控制器
//  Created by 刘超 on 13-5-6.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "XYPieChart.h"
#import "NIDropDown.h"
@interface BIDChartViewController : BIDBaseViewController<XYPieChartDataSource, XYPieChartDelegate,NIDropDownDelegate>
{
    IBOutlet UIButton *btnSelect;
    NIDropDown *dropDown;
}
@property (retain, nonatomic) IBOutlet UIButton *btnSelect;
@property(strong,nonatomic)NSArray*typeBillsArray;
@property(strong,nonatomic)NSMutableArray*typeMoneysArray;
@property(nonatomic, strong) NSArray *sliceColors;
@property (strong, nonatomic) UILabel *roundLabel;
@property (strong, nonatomic) XYPieChart *pieChart;
@property(strong,nonatomic)UILabel*yearLable;
@property(strong,nonatomic)NSString*year;
@property(strong,nonatomic)NSArray*types;
- (IBAction)selectClicked:(id)sender;
@end
