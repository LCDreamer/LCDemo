//
//  BIDBillManagement.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BIDBill.h"
#import "FMDatabase.h"
@interface BIDBillManagement : NSObject
@property(strong,nonatomic)FMDatabase*database;
/*---------------增加一笔账单----------------------------------*/

-(BOOL)saveBill:(BIDBill*)abill;

/*---------------删除一笔账单-----------------------------------*/

-(BOOL)deleteaBill:(BIDBill*)aBill;

/*---------------修改一笔帐------------------------------------*/

-(BOOL)modificationaBill:(BIDBill*)aBill;


/*---------------显示所用的函数---------------------*/
//查找某年所有记帐的月份
-(NSArray*)selectMonthsForYear:(NSString*)aYear;

//通过指定年查找每个月的收入，把每个月的收入存放在数组里
-(NSArray*)selectMonthsIncomeForYear:(NSString*)aYear;

//通过指定年查找每个月的支出，把每个月的收入存放在数组里
-(NSArray*)selectMonthsSpendingForYear:(NSString*)aYear;

//通过指定年查找每个月的收入，把每个月的收入存放在数组里
-(NSMutableArray*)selectMonthsbillsForYear:(NSString*)aYear andMonth:(NSString*)aMonth;

//查找某天的账单
-(BIDBill*)selectaBillForDay:(NSDate*)day;


/*---------------按年、月、日、查找收入支出函数---------------------*/
//查找某年收入
-(float)selectYearIncomeForYear:(NSString*)aYear;

//查找某年的支出
-(float)selectYearSpendingForYear:(NSString*)aYear;

//查找某月的收入
-(float)selectMonthIncomeForYear:(NSString*)aYear andMonth:(NSString*)aMonth;

//查找某月的支出
-(float)selectMonthSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth;

//查找某月的收入，用于主页面刷新
-(float)selectMonthsIncomeForYear:(NSString*)aYear andMonth:(NSString*)aMonth;

//查找某月的支出,用于主页面刷新
-(float)selectMonthsSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth;


//查找某月某种类型的支出,用于预算刷新
-(float)selectTypeSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth andType:(NSString*)type;


//查找某天的收入
-(float)selectDayIncomeForYear:(NSString*)aYear AndMonth:(NSString*)aMoth AndDay:(NSString*)aDay;

//查找某天的支出
-(float)selectDaySpendingForYear:(NSString*)aYear AndMonth:(NSString*)aMoth AndDay:(NSString*)aDay;

/*--------------按类型查找收入支出函数-------------------------------*/

//查找某年所有记帐的类型
-(NSArray*)selectTypesForYear:(NSString*)aYear;

//查找某种类型的收入
-(NSArray*)selectTypesIncomeForYear:(NSString*)aYear;

//查找某种类型的支出
-(NSArray*)selectTypesSpendingForYear:(NSString*)aYear;

//通过指定年查找每个月的收入，把每个月的收入存放在数组里
-(NSArray*)selectTypesbillsForYear:(NSString*)aYear andBillType:(NSUInteger)atype;

//通过年查找收入支出中每种类型的消费
-(NSArray*)selectTypesStatisticsForYear:(NSString*)aYear andBillType:(NSUInteger)atype;
//
-(NSArray*)selectTypesForYear:(NSString*)aYear andBillType:(NSUInteger)atype;

//查找某年所有记帐的成员
-(NSArray*)selectMembersNamesForYear:(NSString*)aYear;

//查找所有成员的收入
-(NSArray*)selectMembersIncomeForYear:(NSString*)aYear;
//查找所有成员的支出
-(NSArray*)selectMembersSpendingForYear:(NSString*)aYear;
@end
