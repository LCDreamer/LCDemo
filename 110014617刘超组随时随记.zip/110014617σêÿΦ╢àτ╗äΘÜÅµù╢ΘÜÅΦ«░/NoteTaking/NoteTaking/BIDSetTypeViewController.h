//
//  BIDSetTypeViewController.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-16.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface BIDSetTypeViewController : BIDBaseViewController

@end
