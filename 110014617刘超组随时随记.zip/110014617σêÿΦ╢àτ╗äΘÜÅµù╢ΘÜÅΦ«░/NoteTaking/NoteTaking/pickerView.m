//
//  pickerView.m
//  Picker
//
//  Created by LiuChao on 13-5-11.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "pickerView.h"
#import "BIDDatabaseManagement.h"
#import "BIDMainViewController.h"
#define kDuration 0.3
@implementation pickerView
@synthesize titleLabel;
@synthesize typeArray;
@synthesize subtypeArray;
@synthesize pickerId;
@synthesize counts;
@synthesize values;
@synthesize memberArray;
@synthesize dic;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (void)viewDidLoad
{
    BIDMainViewController*main=[[BIDMainViewController alloc]init];
    self.typeDelegate=main.self;
}

- (id)initWithTitle:(NSString *)title andTypeKey:(NSUInteger)typeKey delegate:(id)aDelegate
{
    
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"pickerView" owner:self options:nil] objectAtIndex:0];
    if (self) {
        self.typeDelegate = aDelegate;
        self.titleLabel.text = title;
        self.PickerOutlet.dataSource = self;
        self.PickerOutlet.delegate = self;
        self.pickerId=title;
        if ([self.pickerId isEqualToString:@"选择成员"]) {
            BIDDatabaseManagement*da=[[BIDDatabaseManagement alloc]init];
            self.memberArray=[da readMember];
       
        }
        if ([self.pickerId isEqualToString:@"选择类型"]) {
            BIDDatabaseManagement*da=[[BIDDatabaseManagement alloc]init];
            
            self.dic=[da readTypeAandSubtype:typeKey];
            NSLog(@"%d",typeKey);
            NSString*slectedState=[[self.dic allKeys] objectAtIndex:0];
            self.typeArray=[self.dic allKeys];
            self.subtypeArray=[self.dic objectForKey:slectedState];
        }
        
        
        //初始化默认数据
    }
    return self;
}
- (void)showInView:(UIView *) view//初始化控制器
{
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromTop;
    [self setAlpha:1.0f];
    [self.layer addAnimation:animation forKey:@"DDLocateView"];
    
    self.frame = CGRectMake(0, view.frame.size.height - self.frame.size.height, self.frame.size.width, self.frame.size.height);
    
    [view addSubview:self];
}
-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    
    if ([self.pickerId isEqualToString:@"选择类型"]) {
        self.counts=2;
    }
    if ([self.pickerId isEqualToString:@"选择成员"]) {
        self.counts=1;
    }
   return self.counts;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if ([self.pickerId isEqualToString:@"选择类型"]) {
        if (component==KStateComponent) {
            self.counts=[self.typeArray count];
        }else{
            self.counts=[self.subtypeArray count];
        }
    }
    if ([self.pickerId isEqualToString:@"选择成员"]) {
            self.counts=[self.memberArray count];
            
    }
    return self.counts;
}
-(NSString*)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if ([self.pickerId isEqualToString:@"选择类型"]) {
        if (component==KStateComponent) {
            self.values=[self.typeArray objectAtIndex:row];
        }else{
            self.values=[self.subtypeArray objectAtIndex:row];
        }
    }
    if ([self.pickerId isEqualToString:@"选择成员"]) {
        self.values=[self.memberArray objectAtIndex:row];
    }
    return self.values;
}
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if ([self.pickerId isEqualToString:@"选择类型"]) {
        if (component==KStateComponent) {
            NSString*selectedState=[self.typeArray objectAtIndex:row];
            NSMutableArray*array=[self.dic objectForKey:selectedState];
            self.subtypeArray=array;
            [pickerView selectRow:0 inComponent:KzipComponent animated:YES];
            [pickerView reloadComponent:KzipComponent];
        }
    }
    
}
- (IBAction)choose:(id)sender {
    CATransition *animation = [CATransition  animation];
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    [self setAlpha:0.0f];
    [self.layer addAnimation:animation forKey:@"pickerView"];
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
    if ([self.pickerId isEqualToString:@"选择类型"]) {
        NSInteger stateRow=[_PickerOutlet selectedRowInComponent:KStateComponent];
        NSInteger zipRow=[_PickerOutlet selectedRowInComponent:KzipComponent];
        NSString*type=[self.typeArray objectAtIndex:stateRow];
        NSString*subtype=[self.subtypeArray objectAtIndex:zipRow];
        
        if(self.typeDelegate) {
            [self.typeDelegate typeSelection:type Aadsubtype:subtype];
        }
        NSLog(@"%@-----%@",type,subtype);
    }
    if ([self.pickerId isEqualToString:@"选择成员"]) {
        NSInteger stateRow=[_PickerOutlet selectedRowInComponent:KStateComponent];

        NSString*member=[self.memberArray objectAtIndex:stateRow];

        
        if(self.typeDelegate) {
            [self.typeDelegate memberSelection:member];
        }
        NSLog(@"%@",member);
    }
}

- (IBAction)cancel:(id)sender {
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    [self setAlpha:0.0f];
    [self.layer addAnimation:animation forKey:@"pickerView"];
    if(self.typeDelegate) {
        [self.typeDelegate isOpenPicker];
    }
    
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
    
}

- (IBAction)edit:(id)sender {
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    [self setAlpha:0.0f];
    [self.layer addAnimation:animation forKey:@"pickerView"];
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
    if(self.typeDelegate) {
        [self.typeDelegate GotoSetView];
    }
   
}
-(void)MaintabBar:(id)mainDelget{
    self.maindelegate=mainDelget;
}
@end
