//
//  pickerViewDelegate.h
//  Picker
//
//  Created by LiuChao on 13-5-12.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol pickerViewDelegate <NSObject>
@optional
-(void)typeSelection:(NSString*)type Aadsubtype:(NSString*)subtype;
-(void)memberSelection:(NSString*)member;
-(void)GotoSetView;
-(void)isOpenPicker;
@end
