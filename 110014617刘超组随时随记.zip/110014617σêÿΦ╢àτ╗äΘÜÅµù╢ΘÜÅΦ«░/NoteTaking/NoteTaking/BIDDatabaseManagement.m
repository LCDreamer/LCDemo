//
//  BIDDatabaseManagement.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-14.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDDatabaseManagement.h"
#import "BIDBill.h"
@implementation BIDDatabaseManagement
@synthesize database;
@synthesize subtypeArray;
@synthesize dic;
@synthesize billsDic;
@synthesize billsArray;
@synthesize MothSpendingDic;
@synthesize MothIncomeDic;
@synthesize typesDic;
@synthesize typesArray;
@synthesize typeSpendingDic;
@synthesize typeIncomeDic;
-(id)init{
    self=[super init];
    if (self) {
        database=[[FMDatabase alloc]initWithPath:[self dbPath:KMyDatabaseDatabase]];
        if (![self.database open]) {
            NSLog(@"Could not open db.");
        }
        NSString*billListSql=[NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (billId integer primary key AUTOINCREMENT,billType integer,amount float,time text,year text,moth text,type text,subtype text,members text,comment text)",kBillTabel];
        NSString*typeListSql=[NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (typeId integer primary key AUTOINCREMENT,typeKey integer,type text,subtype text)",kTypeTable];
        NSString*budgeListSql=[NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (budgeId integer primary key,budgeTime date,budgeAmount float,budgetype text)",kBudgeTable];
        NSString*memBerListSql=[NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (scenicName integer primary key AUTOINCREMENT,membersName text)",kMemBerTable];
        [self.database executeUpdate:billListSql];
        [self.database executeUpdate:typeListSql];
        [self.database executeUpdate:budgeListSql];
        [self.database executeUpdate:memBerListSql];
    }
    return self;
}
-(NSString*)dbPath:(NSString*)DatabaseName
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    
    NSString *documentDirectory = [paths objectAtIndex:0];
    
    NSString *dbPath = [documentDirectory stringByAppendingPathComponent:DatabaseName];
    return dbPath;
}
+(BIDDatabaseManagement*)sharedDatabaseManagement{
    static BIDDatabaseManagement*aDatabase=nil;
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        aDatabase=[[self alloc]init];
    });
    return aDatabase;
}
-(BOOL)saveBill:(BIDBill*)abill
{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (billType,amount,time,year,moth,type,subtype,members,comment) VALUES (%d,%f,?,?,?,?,?,?,?)",kBillTabel,abill.typeId,abill.amount];
    YesOrNo=[self.database executeUpdate:sql,abill.time,abill.year,abill.moth,abill.type,abill.subtype,abill.membersName,abill.comment];
    
    return YesOrNo;
}
-(BOOL)saveTypeAandSubtype:(BIDBill*)atypeAandSubtype
{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (typeKey,type,subtype) VALUES (%d,?,?)",kTypeTable,atypeAandSubtype.typeId];
    YesOrNo=[self.database executeUpdate:sql,atypeAandSubtype.type,atypeAandSubtype.subtype];
    
    return YesOrNo;
}
-(BOOL)saveMember:(BIDBill*)aMember
{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (membersName) VALUES (?)",kMemBerTable];
    YesOrNo=[self.database executeUpdate:sql,aMember.membersName];
    
    return YesOrNo;
}
-(NSMutableArray*)readMember{
    NSString*sqlit=[NSString stringWithFormat:@"SELECT membersName FROM %@",kMemBerTable];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aMember=[[BIDBill alloc]init];
        aMember.membersId=[[rs stringForColumn:@"scenicName"]intValue];
        aMember.membersName=[rs stringForColumn:@"membersName"];
        [scenicsArray addObject:aMember.membersName];
    }
    return scenicsArray;
    
}
-(NSMutableDictionary*)readTypeAandSubtype:(NSUInteger)typeKey{
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@ where typeKey='%d'",kTypeTable,typeKey];
     self.dic=[[NSMutableDictionary alloc]init];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typeArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aMember=[[BIDBill alloc]init];
        aMember.type=[rs stringForColumn:@"type"];
       
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT subtype FROM %@ where type='%@'",kTypeTable,aMember.type];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.subtypeArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            BIDBill*aMember=[[BIDBill alloc]init];
            aMember.subtype=[rs stringForColumn:@"subtype"];
            [subtypeArray addObject:aMember.subtype];
        }
        [self.dic setObject:subtypeArray forKey:aMember.type];
        [typeArray addObject:aMember.type];
    }
    return self.dic;
}
-(NSMutableDictionary*)readTypeAandSubtypes{
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@",kTypeTable];
    self.dic=[[NSMutableDictionary alloc]init];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typeArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aMember=[[BIDBill alloc]init];
        aMember.type=[rs stringForColumn:@"type"];
        
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT subtype FROM %@ where type='%@'",kTypeTable,aMember.type];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.subtypeArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            BIDBill*aMember=[[BIDBill alloc]init];
            aMember.subtype=[rs stringForColumn:@"subtype"];
            [subtypeArray addObject:aMember.subtype];
        }
        [self.dic setObject:subtypeArray forKey:aMember.type];
        [typeArray addObject:aMember.type];
    }
    return self.dic;
}
-(NSDictionary*)readBillsForYear:(NSString*)year{//读每一年的年账单
    self.billsDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct moth FROM %@",kBillTabel];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aMoth=[[BIDBill alloc]init];
        aMoth.moth=[rs stringForColumn:@"moth"];
        
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT billType,amount,time,year,moth,type,subtype,members,comment FROM %@ where moth='%@' and year=%@",kBillTabel,aMoth.moth,year];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.billsArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            BIDBill*aBill=[[BIDBill alloc]init];
            aBill.billType=[[rs stringForColumn:@"billType"] intValue];
            aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
            aBill.time=[rs dateForColumn:@"time"];
            aBill.moth=[rs stringForColumn:@"moth"];
            aBill.type=[rs stringForColumn:@"type"];
            aBill.subtype=[rs stringForColumn:@"subtype"];
            aBill.membersName=[rs stringForColumn:@"members"];
            aBill.comment=[rs stringForColumn:@"comment"];
            [billsArray addObject:aBill];
        }
        


        [self.billsDic setObject:billsArray forKey:aMoth.moth];
        
        [scenicsArray addObject:aMoth.moth];
        
    }
    NSLog(@"%d",[scenicsArray count]);
    return self.billsDic;
}
-(NSDictionary*)readMothSpendingForYear:(NSString*)year{//读类型月支出
    
    self.MothSpendingDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct moth FROM %@ where year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        BIDBill*aMoth=[[BIDBill alloc]init];
        aMoth.moth=[rs stringForColumn:@"moth"];
        aBill.mothSpend=0.0;
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT amount FROM %@ where moth='%@' and billType='1'",kBillTabel,aMoth.moth];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.billsArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
            aBill.mothSpend=aBill.mothSpend+aBill.amount;
            
            NSLog(@"%f",aBill.mothSpend);
        }
        NSNumber*MothSpend=[[NSNumber alloc]initWithFloat:aBill.mothSpend];
        [self.MothSpendingDic setObject:MothSpend forKey:aMoth.moth];
        [scenicsArray addObject:aMoth.moth];
    }
    return self.MothSpendingDic;
}
-(NSDictionary*)readMothIncomeForYear:(NSString*)year{
    self.MothIncomeDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct moth FROM %@ where year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        BIDBill*aMoth=[[BIDBill alloc]init];
        aMoth.moth=[rs stringForColumn:@"moth"];
        aBill.mothIncome=0.0;
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT amount FROM %@ where moth='%@' and billType='0'",kBillTabel,aMoth.moth];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.billsArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
            aBill.mothIncome=aBill.mothIncome+aBill.amount;
            
            NSLog(@"%f",aBill.mothIncome);
        }
        NSNumber*MothSpend=[[NSNumber alloc]initWithFloat:aBill.mothIncome];
        [self.MothIncomeDic setObject:MothSpend forKey:aMoth.moth];
        [scenicsArray addObject:aMoth.moth];
    }
    return self.MothIncomeDic;
}
-(NSDictionary*)readTypeOfPaymentForYear:(NSString*)year//读每一年的类型账单readTypeOfPaymentForYear:
{
    self.typesDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@",kBillTabel];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*atype=[[BIDBill alloc]init];
        atype.type=[rs stringForColumn:@"type"];
        
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT billId,billType,amount,time,year,moth,type,subtype,members,comment FROM %@ where type='%@' and year='%@'",kBillTabel,atype.type,year];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.typesArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            BIDBill*aBill=[[BIDBill alloc]init];
            aBill.billId=[[rs stringForColumn:@"billId"]intValue];
            aBill.billType=[[rs stringForColumn:@"billType"] intValue];
            aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
            aBill.time=[rs stringForColumn:@"time"];
            aBill.moth=[rs stringForColumn:@"moth"];
            aBill.type=[rs stringForColumn:@"type"];
            aBill.subtype=[rs stringForColumn:@"subtype"];
            aBill.membersName=[rs stringForColumn:@"members"];
            aBill.comment=[rs stringForColumn:@"comment"];
            [typesArray addObject:aBill];
        }
        
        
        
        [self.typesDic setObject:typesArray forKey:atype.type];
        
        [scenicsArray addObject:atype.type];
        
    }
    NSLog(@"%d",[scenicsArray count]);
    return self.typesDic;
    
}
-(NSDictionary*)readTypeSpendingForYear:(NSString*)year//读每一相应月的类型账单年的类型账单
{
    self.typeSpendingDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@ where year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typeSpendingArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        BIDBill*aType=[[BIDBill alloc]init];
        aType.type=[rs stringForColumn:@"type"];
        aType.typeSpend=0.0;
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT amount FROM %@ where type='%@' and billType='1'",kBillTabel,aType.type];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.billsArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
            aBill.typeSpend=aBill.typeSpend+aBill.amount;
            
            NSLog(@"%f",aBill.typeSpend);
        }
        NSNumber*typeSpend=[[NSNumber alloc]initWithFloat:aBill.typeSpend];
        [self.typeSpendingDic setObject:typeSpend forKey:aType.type];
        [typeSpendingArray addObject:aType.type];
    }
    return self.typeSpendingDic;
    
}
-(NSDictionary*)readTypeIncomeForYear:(NSString*)year//读每一年相应月的的类型账单
{
    self.typeIncomeDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@ where year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typeIncomeArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        BIDBill*aType=[[BIDBill alloc]init];
        aType.type=[rs stringForColumn:@"type"];
        aType.typeIncome=0.0;
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT amount FROM %@ where type='%@' and billType='0'",kBillTabel,aType.type];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        self.billsArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
            aBill.typeIncome=aBill.typeIncome+aBill.amount;
            
            NSLog(@"%f",aBill.typeIncome);
        }
        NSNumber*typeIncome=[[NSNumber alloc]initWithFloat:aBill.typeIncome];
        [self.typeIncomeDic setObject:typeIncome forKey:aType.type];
        [typeIncomeArray addObject:aType.type];
    }
    return self.typeIncomeDic;
    
}
-(NSArray*)readMothsForYear:(NSString*)year
{
    self.billsDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct moth FROM %@ where year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aMoth=[[BIDBill alloc]init];
        aMoth.moth=[rs stringForColumn:@"moth"];
        [scenicsArray addObject:aMoth.moth];
    }
    NSLog(@"%d",[scenicsArray count]);
    return scenicsArray;
}
-(NSArray*)readTypesForYear:(NSString*)year
{
    self.typeSpendingDic=[[NSMutableDictionary alloc]init];
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@ where year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typeSpendingArray=[[NSMutableArray alloc]init];
     while ([rs next]) {
         BIDBill*aType=[[BIDBill alloc]init];
         aType.type=[rs stringForColumn:@"type"];
         [typeSpendingArray addObject:aType.type];
     }
    return typeSpendingArray;
}
-(NSString*)yearsOfIncomeForYear:(NSString*)year//读年收入
{
    BIDBill*aBill=[[BIDBill alloc]init];
    aBill.yearsIncome=0.0;
     NSString*sqlit=[NSString stringWithFormat:@"SELECT amount FROM %@ where billType='0'and year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    while ([rs next]) {
        BIDBill*yearsIncome=[[BIDBill alloc]init];
        yearsIncome.amount=[[rs stringForColumn:@"amount"] floatValue];
        aBill.yearsIncome=aBill.yearsIncome+yearsIncome.amount;
    }
    NSString*yearIncome=[NSString stringWithFormat:@"%0.2f",aBill.yearsIncome];
    return yearIncome;
}
-(NSString*)yearsOfSpendingForYear:(NSString*)year//读年支出
{
    BIDBill*aBill=[[BIDBill alloc]init];
    aBill.yearsIncome=0.0;
    NSString*sqlit=[NSString stringWithFormat:@"SELECT amount FROM %@ where billType='1' and year='%@'",kBillTabel,year];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    while ([rs next]) {
        BIDBill*yearsSpending=[[BIDBill alloc]init];
        yearsSpending.amount=[[rs stringForColumn:@"amount"] floatValue];
        aBill.yearsIncome=aBill.yearsIncome+yearsSpending.amount;
    }
    NSString*yearSpending=[NSString stringWithFormat:@"%0.2f",aBill.yearsIncome];
    return yearSpending;
}
@end
