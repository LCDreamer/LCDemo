//
//  BIDType.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-23.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDType.h"

@implementation BIDType
@synthesize typeId;
@synthesize subtypeId;
@synthesize type;
@synthesize subtype;
@end
