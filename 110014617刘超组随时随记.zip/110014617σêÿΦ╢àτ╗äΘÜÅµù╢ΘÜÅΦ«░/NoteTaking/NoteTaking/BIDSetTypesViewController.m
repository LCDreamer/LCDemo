//
//  BIDSetTypesViewController.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-16.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDSetTypesViewController.h"
#import "BIDAddTypeViewController.h"
#import "BIDAppDelegate.h"
#import "BIDAddTypeViewController.h"
#import "BIDDatabaseManagement.h"
#import "BIDSetSubTypeViewController.h"
#import "BIDTypeManagement.h"
@interface BIDSetTypesViewController ()

@end

@implementation BIDSetTypesViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"设置类型";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    BIDDatabaseManagement*da=[[BIDDatabaseManagement alloc]init];
    self.dic=[da readTypeAandSubtypes];
    self.typeArray=[[self.dic allKeys] mutableCopy];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    BIDDatabaseManagement*da=[[BIDDatabaseManagement alloc]init];
    self.dic=[da readTypeAandSubtypes];
    self.typeArray=[[self.dic allKeys] mutableCopy];
    [self.tableView reloadData];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.typeArray count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSUInteger row=[indexPath row];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text=[self.typeArray objectAtIndex:row];
    return cell;
}

- (IBAction)addType:(id)sender {
    BIDAddTypeViewController*addTypeViewController=[[BIDAddTypeViewController alloc]init];
    [self.navigationController pushViewController:addTypeViewController animated:YES];
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSUInteger row=[indexPath row];
    NSString*key=[self.typeArray objectAtIndex:row];
    BIDSetSubTypeViewController*setSubType=[[BIDSetSubTypeViewController alloc]init];
    setSubType.subTypeArray=[self.dic objectForKey:key];
    [self.navigationController pushViewController:setSubType animated:YES];
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger row=[indexPath row];
    BIDTypeManagement*typeManagement=[[BIDTypeManagement alloc]init];
    NSString*aType=[self.typeArray objectAtIndex:row];
    [typeManagement deletetype:aType];
    [self.typeArray removeObjectAtIndex:row];
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [tableView reloadData];
}

@end
