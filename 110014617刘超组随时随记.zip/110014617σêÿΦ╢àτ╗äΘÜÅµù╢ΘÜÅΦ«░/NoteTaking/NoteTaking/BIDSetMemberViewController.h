//
//  BIDSetMemberViewController.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-17.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"

@interface BIDSetMemberViewController : BIDBaseViewController<UITabBarControllerDelegate,UITableViewDataSource>
- (IBAction)addMember:(id)sender;
@property(strong,nonatomic)NSMutableArray*memberArray;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end
