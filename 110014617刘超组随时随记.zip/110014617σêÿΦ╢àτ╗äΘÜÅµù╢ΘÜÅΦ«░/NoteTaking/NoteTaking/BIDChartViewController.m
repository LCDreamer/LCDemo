		//
//  BIDChartViewController.m
//  NoteTaking
//  按图表统计视图控制器
//  Created by 刘超 on 13-5-6.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDChartViewController.h"
#import "Config.h"
#import "XYPieChart.h"
#import "QuartzCore/QuartzCore.h"
#import "BIDBillManagement.h"
#import "BIDBill.h"
@interface BIDChartViewController ()

@end

@implementation BIDChartViewController
@synthesize typeBillsArray;
@synthesize typeMoneysArray;
@synthesize sliceColors;
@synthesize roundLabel=_roundLabel;
@synthesize pieChart=_pieChart;
@synthesize year;
@synthesize yearLable;
@synthesize btnSelect;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.hidesBottomBarWhenPushed=YES;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
    // [self.view setBackgroundColor:[UIColor whiteColor]];
    btnSelect.layer.borderWidth = 1;
    btnSelect.layer.borderColor = [[UIColor blackColor] CGColor];
    
 //   [btnSelect setBackgroundColor:[UIColor clearColor]];
    [btnSelect setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"blue.jpg"]]];
    
    btnSelect.layer.cornerRadius = 5;
    self.typeMoneysArray=(NSMutableArray*)[self statisticalConsumptionForYear:@"2013" andBillType:0];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    self.types=[bill selectTypesForYear:@"2013" andBillType:0];
    [self selectYear];
    
    [self initPieChartUI];
    
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
//    [self initPieChartUI];
//    [self.pieChart reloadData];
    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 1 * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void){
//        [self.pieChart setSliceSelectedAtIndex:0];
//    });
//    
//    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, 2 * NSEC_PER_SEC), dispatch_get_main_queue(), ^(void){
//        [self.pieChart setSliceDeselectedAtIndex:0];
//    });
}

- (void)initPieChartUI {
    
    UIImage *pieChartBackground = [UIImage imageNamed:@"PhotoFrame"];
    UIImageView *pieChartBackgroundView = [[UIImageView alloc] initWithFrame:CGRectMake((320 - pieChartBackground.size.width) / 2, 80, pieChartBackground.size.width, pieChartBackground.size.height)];
    pieChartBackgroundView.image = pieChartBackground;
    
    _pieChart = [[XYPieChart alloc] initWithFrame:CGRectMake((320 - 260) / 2, 85, 260, 260)];
    //   _pieChart.backgroundColor = [UIColor whiteColor];
    _pieChart.delegate = self;
    _pieChart.dataSource = self;
    _roundLabel = [[UILabel alloc] initWithFrame:CGRectMake((320 - 90) / 2, 175, 90, 90)];
    _roundLabel.font = [UIFont fontWithName:HEITI_SC_MEDIUM size:20.0f];
    _roundLabel.textColor = RGB(104, 114, 121);
    _roundLabel.shadowColor = [UIColor clearColor];
    _roundLabel.shadowOffset = CGSizeMake(0, 1);
    _roundLabel.backgroundColor = RGB(234, 234, 234);
    _roundLabel.textAlignment = UITextAlignmentCenter;
    
    [_pieChart setStartPieAngle:M_PI_2];
    [_pieChart setAnimationSpeed:1.0];
    [_pieChart setLabelFont:[UIFont fontWithName:@"DBLCDTempBlack" size:18]];
    [_pieChart setLabelRadius:80];
    [_pieChart setShowPercentage:NO];
    //    [_pieChart setPieBackgroundColor:[UIColor colorWithWhite:0.95 alpha:1]];
    [_pieChart setPieCenter:CGPointMake(_pieChart.bounds.size.width / 2, _pieChart.bounds.size.height / 2)];
    //    [_pieChart setLabelShadowColor:[UIColor blackColor]];
    
    [_roundLabel.layer setCornerRadius:_roundLabel.bounds.size.width / 2];
    
    self.sliceColors =[NSArray arrayWithObjects:
                       [UIColor colorWithRed:246/255.0 green:155/255.0 blue:0/255.0 alpha:1],
                       [UIColor colorWithRed:129/255.0 green:195/255.0 blue:29/255.0 alpha:1],
                       [UIColor colorWithRed:62/255.0 green:173/255.0 blue:219/255.0 alpha:1],
                       [UIColor colorWithRed:229/255.0 green:66/255.0 blue:115/255.0 alpha:1],
                       [UIColor colorWithRed:148/255.0 green:141/255.0 blue:139/255.0 alpha:1],nil];
    
    [self.view addSubview:pieChartBackgroundView];
    [self.view addSubview:_pieChart];
    [self.view addSubview:_roundLabel];
    
    [self.pieChart reloadData];
}


#pragma mark - XYPieChart Data Source

- (NSUInteger)numberOfSlicesInPieChart:(XYPieChart *)pieChart {
    return self.typeMoneysArray.count;
}

- (CGFloat)pieChart:(XYPieChart *)pieChart valueForSliceAtIndex:(NSUInteger)index {
    return [[self.typeMoneysArray objectAtIndex:index] intValue];
}

- (UIColor *)pieChart:(XYPieChart *)pieChart colorForSliceAtIndex:(NSUInteger)index {
    return [self.sliceColors objectAtIndex:(index % self.sliceColors.count)];
}
#pragma mark - XYPieChart Delegate

- (void)pieChart:(XYPieChart *)pieChart didSelectSliceAtIndex:(NSUInteger)index {
    //NSUInteger rwo=index-1;
    _roundLabel.text=[self.types objectAtIndex:index];
    
}
-(void)selectYear{
    UIView*yearView=[[UIView alloc]initWithFrame:CGRectMake(15, 30, 140, 30)];
    [yearView setBackgroundColor:[UIColor clearColor]];
    UIButton *prevButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [prevButton setImage:[UIImage imageNamed:@"left_arrow.png"] forState:UIControlStateNormal];
    prevButton.frame=CGRectMake(0, 2, 25, 25);
    [prevButton addTarget:self action:@selector(moveCalendarToPreviousYear) forControlEvents:UIControlEventTouchUpInside];
    [yearView addSubview:prevButton];
    
    
    UIButton *nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [nextButton setImage:[UIImage imageNamed:@"right_arrow.png"] forState:UIControlStateNormal];
    nextButton.frame=CGRectMake(115, 2, 25, 25);
    [nextButton addTarget:self action:@selector(moveCalendarToNextYear) forControlEvents:UIControlEventTouchUpInside];
    [yearView addSubview:nextButton];
    
    self.yearLable=[[UILabel alloc]initWithFrame:CGRectMake(30, 2, 80, 25)];
    NSDate* today=[NSDate date];
    NSDateFormatter*catime=[[NSDateFormatter alloc]init];
    [catime setDateStyle:NSDateFormatterMediumStyle];
    [catime setTimeStyle:NSDateFormatterShortStyle];
    [catime setDateFormat:@"YYYY"];
    self.year=[catime stringFromDate:today];
    NSString* thisYear=[NSString stringWithFormat:@"%@年",self.year];
    [self.yearLable setText:thisYear];
    [self.yearLable setTextAlignment:NSTextAlignmentCenter];
    [yearView addSubview:yearLable];
    [self.view addSubview:yearView];
    NSString *newYear = [thisYear substringToIndex:4];
    NSLog(@"%@",newYear);
    
}
-(void)moveCalendarToPreviousYear{
    NSInteger years=[self.yearLable.text intValue]-1;
    NSString*newYear=[NSString stringWithFormat:@"%d年",years];
    [self.yearLable setText:newYear];
    NSString *newYears = [newYear substringToIndex:4];
    NSLog(@"%@",newYears);
    self.year=newYears;
    self.typeMoneysArray=(NSMutableArray*)[self statisticalConsumptionForYear:self.year andBillType:0];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    self.types=[bill selectTypesForYear:self.year andBillType:0];
    [self initPieChartUI];
    [self.pieChart reloadData];
    
}
-(void)moveCalendarToNextYear{
    NSInteger years=[self.yearLable.text intValue]+1;
    NSString*newYear=[NSString stringWithFormat:@"%d年",years];
    [self.yearLable setText:newYear];
    NSString *newYears = [newYear substringToIndex:4];
    NSLog(@"%@",newYears);
    self.year=newYears;
    self.typeMoneysArray=(NSMutableArray*)[self statisticalConsumptionForYear:self.year andBillType:0];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    self.types=[bill selectTypesForYear:self.year andBillType:0];
    [self initPieChartUI];
    [self.pieChart reloadData];
    
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (IBAction)selectClicked:(id)sender {
    NSArray * arr = [[NSArray alloc] init];
    arr = [NSArray arrayWithObjects:@"收入", @"支出",nil];
    if(dropDown == nil) {
        CGFloat f = 80;
        dropDown = [[NIDropDown alloc]initShowDropDown:sender :&f :arr];
        dropDown.delegate = self;
    }
    else {
        [dropDown hideDropDown:sender];
    }
}
- (void) niDropDownDelegateMethod: (NIDropDown *) sender {
    [self rel];
}

-(void)rel{
    dropDown = nil;
}
-(void)getButtonForTitle:(NSString *)title{
    NSLog(@"%@",title);
    NSUInteger billType;
    if ([title isEqualToString:@"收入"]) {
        billType=0;
    }else{
        billType=1;
    }
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    NSMutableArray*typemoneys=[[NSMutableArray alloc]init];
    NSArray*billsArray=[bill selectTypesbillsForYear:self.year andBillType:billType];
    [bill selectTypesStatisticsForYear:self.year andBillType:billType];
    self.types=[bill selectTypesForYear:self.year andBillType:billType];
    NSArray*typesArray=[bill selectTypesForYear:self.year];
    for (int i=0; i<[typesArray count]; i++) {
        float amount=0;
        for (int j=0; j<[billsArray count]; j++) {
            BIDBill*abill=[billsArray objectAtIndex:j];
            
            if ([[typesArray objectAtIndex:i] isEqualToString:abill.type]) {
                amount=amount+abill.amount;
            }
        }
        NSString*amounts=[NSString stringWithFormat:@"%0.2f",amount];
        if (amount!=0) {
            [typemoneys addObject:amounts];
        }
        
        self.typeMoneysArray=typemoneys;
    }
    [self initPieChartUI];
    //[self.pieChart reloadData];
}

-(NSMutableArray*)statisticalConsumptionForYear:(NSString*)aYear andBillType:(NSUInteger)atype{
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    NSMutableArray*typemoneys=[[NSMutableArray alloc]init];
    NSArray*billsArray=[bill selectTypesbillsForYear:aYear andBillType:atype];
    NSArray*typesArray=[bill selectTypesForYear:aYear];
    for (int i=0; i<[typesArray count]; i++) {
        float amount=0;
        for (int j=0; j<[billsArray count]; j++) {
            BIDBill*abill=[billsArray objectAtIndex:j];
            
            if ([[typesArray objectAtIndex:i] isEqualToString:abill.type]) {
                amount=amount+abill.amount;
            }
        }
        NSString*amounts=[NSString stringWithFormat:@"%0.2f",amount];
        if (amount!=0) {
            [typemoneys addObject:amounts];
        }
    
    }
    return typemoneys;
}
@end
