//
//  BIDBaseViewController.m
//  NoteTaking
//
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "BIDAppDelegate.h"
@interface BIDBaseViewController ()
@property (weak, nonatomic) UIImage * myBackgroundImage;
@end

@implementation BIDBaseViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //    将backgroundImg赋给myBackgroundImage
    self.myBackgroundImage=[(id)[[UIApplication sharedApplication] delegate] backgroundImg];
    //    设置背景图片
    self.view.backgroundColor=[UIColor colorWithPatternImage:self.myBackgroundImage];
}

- (void)viewWillAppear:(BOOL)animated{
    //    设置一个UIImage对象，用以获取最新的背景图片名
    UIImage *image=[(id)[[UIApplication sharedApplication] delegate] backgroundImg];
    if (self.myBackgroundImage !=image) {
        self.view.backgroundColor=[UIColor colorWithPatternImage:image];
        self.myBackgroundImage=image;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
