//
//  BIDSetMemberViewController.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-17.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDSetMemberViewController.h"
#import "BIDAddMemberViewController.h"
#import "BIDAppDelegate.h"
#import "BIDAddMemberViewController.h"
#import "BIDDatabaseManagement.h"
#import "BIDMembersManagement.h"
@interface BIDSetMemberViewController ()

@end

@implementation BIDSetMemberViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"成员设置";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    BIDDatabaseManagement*da=[[BIDDatabaseManagement alloc]init];
    self.memberArray=[da readMember];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    BIDDatabaseManagement*da=[[BIDDatabaseManagement alloc]init];
    self.memberArray=[da readMember];
    [self.tableView reloadData];
    
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addMember:(id)sender {
//    点击按钮后视图将跳转到BIDAddMemberViewController视图
    BIDAddMemberViewController*addMemberViewController=[[BIDAddMemberViewController alloc]init];
    [self.navigationController pushViewController:addMemberViewController animated:YES];
    
}
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [self.memberArray count];
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSUInteger row=[indexPath row];
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell==nil) {
        cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    cell.textLabel.text=[self.memberArray objectAtIndex:row];
    return cell;
}
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger row=[indexPath row];
    BIDMembersManagement*membersManagement=[[BIDMembersManagement alloc]init];
    NSString*aMember=[self.memberArray objectAtIndex:row];
    [membersManagement deleteMembe:aMember];
    [self.memberArray removeObjectAtIndex:row];
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [tableView reloadData];
}
@end
