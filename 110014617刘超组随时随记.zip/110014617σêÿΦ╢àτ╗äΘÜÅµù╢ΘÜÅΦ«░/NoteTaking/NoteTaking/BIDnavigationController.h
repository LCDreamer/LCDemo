//
//  BIDnavigationController.h
//  NavigationController
//
//  Created by 刘超 on 13-4-1.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BIDnavigationController : UINavigationController

@end
