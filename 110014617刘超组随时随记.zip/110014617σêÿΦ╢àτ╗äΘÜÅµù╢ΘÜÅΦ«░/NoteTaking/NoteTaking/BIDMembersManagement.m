//
//  BIDMembersManagement.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDMembersManagement.h"
#import "BIDDatabaseManagement.h"
@implementation BIDMembersManagement
-(id)init{
    self=[super init];
    if (self) {
        BIDDatabaseManagement*Database=[BIDDatabaseManagement sharedDatabaseManagement];
        self.database=Database.database;
    }
    return self;
}
-(BOOL)saveMember:(BIDMembers*)aMember
{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (membersName) VALUES (?)",kMemBerTable];
    YesOrNo=[self.database executeUpdate:sql,aMember.membersName];
    
    return YesOrNo;
}
-(NSArray*)readMember{
    NSString*sqlit=[NSString stringWithFormat:@"SELECT membersName FROM %@",kMemBerTable];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDMembers*aMember=[[BIDMembers alloc]init];
        aMember.membersName=[rs stringForColumn:@"membersName"];
        [scenicsArray addObject:aMember.membersName];
    }
    return scenicsArray;
    
}
-(BOOL)deleteMembe:(NSString*)aMembe{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"DELETE FROM %@ where membersName='%@'",kMemBerTable,aMembe];
    YesOrNo=[self.database executeUpdate:sql];
    
    return YesOrNo;

}
@end
