//
//  BIDBudgetViewController.m
//  NoteTaking
//  预算控制器
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBudgetViewController.h"
#import "AppButton.h"
#import "BIDBudgetingViewController.h"
#import "BIDTypeManagement.h"
#import "FPNumberPadView.h"
#import "BIDBudget.h"
#import "BIDBudgetManagement.h"
#import "BIDBillManagement.h"
#import "DPMeterView.h"
#define WIDTH  150
#define HIGHT  150

#define TAGH  10

#define BTNWIDTH  WIDTH - TAGH
#define BTNHIGHT  HIGHT - TAGH
@interface BIDBudgetViewController ()
{
    BOOL m_bTransform;
    NSMutableArray *m_arData;
}
@property (strong, nonatomic)FPNumberPadView * myNumKeyboard;
@end

@implementation BIDBudgetViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"预算";
    }
    return self;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self createData];
    [self showBudgetBill];
    [self refreshTheAdvanceAmount];
    
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self createData];
    [self showBudgetBill];
    [self refreshTheAdvanceAmount];
    
    
}
-(void)showBudgetBill{
    
    //初始化数字键盘
    
    self.myNumKeyboard=[[FPNumberPadView alloc]initWithFrame:CGRectMake(0, 0, 320, 256)];
    //设置代理
    self.myNumKeyboard.savdelegate=self;
	// Do any additional setup after loading the view, typically from a nib.
    int width = self.scrollViewOutlet.frame.size.width/2;
    for (int i = 0; i < [m_arData count]; i++)
    {
        BIDBudget*budget=[m_arData objectAtIndex:i];
        int t = i/2;
        int d = fmod(i, 2);
        UIView *nView = [[UIView alloc] initWithFrame:CGRectMake(width * d + 5, HIGHT * t +10, WIDTH, HIGHT)] ;
        //[nView setBackgroundColor:[UIColor redColor]];
        CAppButton *appBtn = [CAppButton BtnWithType:UIButtonTypeCustom];
        [appBtn setFrame:CGRectMake(TAGH, TAGH, BTNWIDTH, BTNHIGHT)];
        [appBtn setImage:[UIImage imageNamed:@"bu.png"] forState:UIControlStateNormal];
        [appBtn setTitle:budget.type forState:UIControlStateNormal];
        [appBtn addTarget:self action:@selector(btnClicked:event:) forControlEvents:UIControlEventTouchUpInside];
        appBtn.tag = i;
        UIImageView *tagImgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
        [tagImgView setImage:[UIImage imageNamed:@"deleteTag.png"]];
        //[appBtn addSubview:tagImgView];
        
        UILabel*budgetAmount=[[UILabel alloc]initWithFrame:CGRectMake(25, 0, 100, 20)];
        budgetAmount.text=@"预算金额：";
        
        [appBtn addSubview:budgetAmount];
        
        UITextField*budgetAmountOutlet=[[UITextField alloc]initWithFrame:CGRectMake(25, 25, 100, 20)];
        NSString*aBudgetAmount=[NSString stringWithFormat:@"%0.2f",budget.budgeAmount];
        budgetAmountOutlet.text=aBudgetAmount;
        budgetAmountOutlet.tag=i;
        
        //UIControlEventEditingDidBegin当文本控件中开始编辑时发送通知。
        [budgetAmountOutlet addTarget:self action:@selector(willStartEditing:) forControlEvents:UIControlEventEditingDidBegin];
        
        //UIControlEventEditingDidEnd当文本控件中编辑结束时发送通知。
        [budgetAmountOutlet addTarget:self action:@selector(willStopEditing:) forControlEvents:UIControlEventEditingDidEnd];
        
        [appBtn addSubview:budgetAmountOutlet];
        
        UILabel*availableAmount=[[UILabel alloc]initWithFrame:CGRectMake(25, 50, 100, 20)];
        availableAmount.text=@"可用金额：";
        [appBtn addSubview:availableAmount];
        
        UILabel*availableAmountOutlet=[[UILabel alloc]initWithFrame:CGRectMake(25, 75, 100, 20)];
        NSString*aRestAmount=[NSString stringWithFormat:@"%0.2f",budget.restAmount];
        availableAmountOutlet.text=aRestAmount;
        [appBtn addSubview:availableAmountOutlet];
        //[tagImgView setHidden:YES];
        DPMeterView*met=[[DPMeterView alloc]initWithFrame:CGRectMake(110, 110, 40, 40)];
        [met setTrackTintColor:[UIColor lightGrayColor]];
        [met setProgressTintColor:[UIColor darkGrayColor]];
        [appBtn addSubview:met];
        [nView addSubview:appBtn];
        
        
        
        [self.scrollViewOutlet addSubview:nView];
        //nView.userInteractionEnabled = NO;
    }
    self.scrollViewOutlet.contentSize=CGSizeMake(self.scrollViewOutlet.frame.size.width,self.scrollViewOutlet.frame.size.height*2);
    UITapGestureRecognizer *tapGestureTel2 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(TwoPressGestureRecognizer:)];
    [tapGestureTel2 setNumberOfTapsRequired:2];
    [tapGestureTel2 setNumberOfTouchesRequired:1];
    [self.scrollViewOutlet addGestureRecognizer:tapGestureTel2];
}

-(void)willStartEditing:(UITextField *)sender{

    if ([sender.text isEqualToString:@"0.00"]) {
        sender.text=@"";
    }

    self.myNumKeyboard.textField=sender;
    self.myNumKeyboard.shouZhiSegment.hidden=YES;
//    sender.inputView=self.myNumKeyboard;
}

-(void)willStopEditing:(UITextField *)sender{
    if (sender.text.length==0) {
        sender.text=@"0.00";
    }
}
                                                
- (void)createData
{
    BIDTypeManagement*typeyManagement=[[BIDTypeManagement alloc]init];
    NSDictionary*dic=[typeyManagement readTypeAandSubtype];
    m_arData=(NSMutableArray*)[dic allKeys];
    BIDBudgetManagement*budgetManagement=[[BIDBudgetManagement alloc]init];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    NSDate* today=[NSDate date];
    NSString*atoday=[NSString stringWithFormat:@"%@",today];
    m_arData=[[NSMutableArray alloc]init];
    NSArray*dateAarry=[atoday componentsSeparatedByString:@"+"];
    NSDateFormatter*catime=[[NSDateFormatter alloc]init];
    [catime setDateStyle:NSDateFormatterMediumStyle];
    [catime setTimeStyle:NSDateFormatterShortStyle];
    [catime setDateFormat:@"YYYY"];
    NSString*year=[catime stringFromDate:today];
    NSDateFormatter*atime=[[NSDateFormatter alloc]init];
    [atime setDateStyle:NSDateFormatterMediumStyle];
    [atime setTimeStyle:NSDateFormatterShortStyle];
    [atime setDateFormat:@"MM"];
    NSString*moth=[atime stringFromDate:today];
    for (int i=0; i<[[dic allKeys] count]; i++) {
        BIDBudget*bug=[[BIDBudget alloc]init];
        NSString *atype=[[dic allKeys]objectAtIndex:i];
        bug.type=atype;
        bug.budgeAmount=[budgetManagement selectbudgeAmountForType:atype andYear:year andMonth:moth];
        float spendAmount=[bill selectTypeSpendingForYear:year andMonth:moth andType:atype];
        bug.restAmount=bug.budgeAmount-spendAmount;
        bug.budgeTime=[dateAarry objectAtIndex:0];
        [m_arData addObject:bug];
        
    }
    
}

- (void)btnClicked:(id)sender event:(id)event
{
    UIButton *btn = (UIButton *)sender;
    //[self deleteAppBtn:btn.tag];
    NSLog(@"%d",btn.tag);
    NSLog(@"%@",btn.titleLabel.text);
    //UITextField*Text=(UITextField*)[btn.subviews objectAtIndex:3];
    //[Text setText:@"123"];
   // BIDBudgetingViewController*budgetingViewController=[[BIDBudgetingViewController alloc]init];
    //[self.navigationController pushViewController:budgetingViewController animated:YES];
}
-(void)TwoPressGestureRecognizer:(UIGestureRecognizer *)gr
{
    if(m_bTransform==NO)
        return;
    
    for (UIView *view in self.scrollViewOutlet.subviews)
    {
        view.userInteractionEnabled = NO;
        for (UIView *v in view.subviews)
        {
            if ([v isMemberOfClass:[UIImageView class]])
                [v setHidden:YES];
        }
    }
    m_bTransform = NO;
    [self EndWobble];
}

-(void)BeginWobble
{
  
    for (UIView *view in self.scrollViewOutlet.subviews)
    {
        srand([[NSDate date] timeIntervalSince1970]);
        float rand=(float)random();
        CFTimeInterval t=rand*0.0000000001;
        [UIView animateWithDuration:0.1 delay:t options:0  animations:^
         {
             view.transform=CGAffineTransformMakeRotation(-0.05);
         } completion:^(BOOL finished)
         {
             [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionRepeat|UIViewAnimationOptionAutoreverse|UIViewAnimationOptionAllowUserInteraction  animations:^
              {
                  view.transform=CGAffineTransformMakeRotation(0.05);
              } completion:^(BOOL finished) {}];
         }];
    }
   
}

-(void)EndWobble
{
   
    for (UIView *view in self.scrollViewOutlet.subviews)
    {
        [UIView animateWithDuration:0.1 delay:0 options:UIViewAnimationOptionAllowUserInteraction|UIViewAnimationOptionBeginFromCurrentState animations:^
         {
             view.transform=CGAffineTransformIdentity;
             for (UIView *v in view.subviews)
             {
                 if ([v isMemberOfClass:[UIImageView class]])
                     [v setHidden:YES];
             }
         } completion:^(BOOL finished) {}];
    }

}

#pragma mark - savBudgetDelegate
-(BOOL)saveBudet:(int)index andTitle:(NSString*)title{
    NSLog(@"%d",index);
    BIDBudget*aBuget=[m_arData objectAtIndex:index];
    aBuget.budgeAmount=[title floatValue];
    NSDate* today=[NSDate date];
    NSDateFormatter*catime=[[NSDateFormatter alloc]init];
    [catime setDateStyle:NSDateFormatterMediumStyle];
    [catime setTimeStyle:NSDateFormatterShortStyle];
    [catime setDateFormat:@"YYYY"];
    NSString*year=[catime stringFromDate:today];
    NSDateFormatter*atime=[[NSDateFormatter alloc]init];
    [atime setDateStyle:NSDateFormatterMediumStyle];
    [atime setTimeStyle:NSDateFormatterShortStyle];
    [atime setDateFormat:@"MM"];
    NSString*moth=[atime stringFromDate:today];
    BIDBudgetManagement*budgetManagement=[[BIDBudgetManagement alloc]init];
    
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
   
    BOOL YesOrNo=[budgetManagement isEqualToType:aBuget.type ForYear:year andMonth:moth];
    if (YesOrNo) {
        
        [budgetManagement modifyBudget:aBuget];
        [self refreshTheAdvanceAmount];
    }else{
        
        [budgetManagement saveMember:aBuget];
        [self refreshTheAdvanceAmount];
    }
    aBuget.budgeAmount=[budgetManagement selectbudgeAmountForType:aBuget.type andYear:year andMonth:moth];
    float spendAmount=[bill selectTypeSpendingForYear:year andMonth:moth andType:aBuget.type];
    aBuget.restAmount=aBuget.budgeAmount-spendAmount;
    [self showBudgetBill];
    UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"保存成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    
    [alter show];
    return YES;
}
-(void)refreshTheAdvanceAmount{
    BIDBudgetManagement*budgetManagement=[[BIDBudgetManagement alloc]init];
    float BudgetSpending=[budgetManagement selectMonthsBudgetSpendingForYear:@"2013" andMonth:@"07"];
    NSString*Budget=[NSString stringWithFormat:@"%0.2f",BudgetSpending];
    BIDBillManagement*billManagement=[[BIDBillManagement alloc]init];
    float MonthsSpending=[billManagement selectMonthsSpendingForYear:@"2013" andMonth:@"07"];
    NSString*Spending=[NSString stringWithFormat:@"%0.2f",MonthsSpending];
    NSString*available=[NSString stringWithFormat:@"%0.2f",BudgetSpending-MonthsSpending];
    self.allBudgetOutlet.text=Budget;
    self.SpendingOutlet.text=Spending;
    self.availableOutlet.text=available;
}

@end
