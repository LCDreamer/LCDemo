//
//  ViewController.m
//  KuaiPanOpenAPIDemo
//
//  Created by Jinbo He on 12-7-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "ViewController.h"


@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    _progress.hidden = YES;
    
    self.title = @"我的应用";
    self.navigationController.navigationBar.tintColor = [UIColor blueColor];
    //设置返回按钮
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStylePlain target:nil action:nil];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
}

- (void)dealloc
{
    if (_getUserInfoOp) {
        [_getUserInfoOp cancelOperation];
        //[_getUserInfoOp release];
    }
    
    //[super dealloc];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
}

@end
