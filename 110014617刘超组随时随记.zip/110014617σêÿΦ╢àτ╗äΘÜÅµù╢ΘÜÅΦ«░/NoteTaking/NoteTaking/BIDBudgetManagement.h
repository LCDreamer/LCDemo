//
//  BIDBudgetManagement.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "BIDBudget.h"
@interface BIDBudgetManagement : NSObject
@property(strong,nonatomic)FMDatabase*database;
/*-------------增加类和子类-------------------*/

-(BOOL)saveMember:(BIDBudget*)aBudget;

/*-------------查类和子类-------------------*/

-(BOOL)isEqualToType:(NSString*)type ForYear:(NSString*)aYear andMonth:(NSString*)aMonth;//读成员
/*-------------修改账单---------------------*/

-(BOOL)modifyBudget:(BIDBudget*)aBudget;
/*-------------查找账单-------------------------*/
-(float)selectbudgeAmountForType:(NSString*)type andYear:(NSString*)aYear andMonth:(NSString*)aMonth;

//查找某月的支出,用于主页面刷新
-(float)selectMonthsBudgetSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth;
@end
