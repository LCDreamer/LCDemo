//
//  BIDAddMemberViewController.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-17.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDAddMemberViewController.h"
#import "BIDBill.h"
#import "BIDDatabaseManagement.h"
@interface BIDAddMemberViewController ()

@end

@implementation BIDAddMemberViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"添加成员";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setUIBarButtonItem];
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self setUIBarButtonItem];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)setUIBarButtonItem{//初始化右边的保存按钮
    UIBarButtonItem*leftItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(save)];
    self.navigationItem.rightBarButtonItem=leftItem;
}
-(void)save{
    BIDBill*aMember=[[BIDBill alloc]init];
    aMember.membersName=self.memberOutlet.text;
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    [databaseManagement saveMember:aMember];
    UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"保存成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    
    [alter show];
    
}
@end
