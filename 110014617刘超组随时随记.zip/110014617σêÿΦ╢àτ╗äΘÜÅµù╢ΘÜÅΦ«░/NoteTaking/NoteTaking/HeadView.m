//
//  HeadView.m
//  Test04
//
//  Created by HuHongbing on 9/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "HeadView.h"

@implementation HeadView
@synthesize delegate = _delegate;
@synthesize section,open,backBtn;
@synthesize spending,income,balance,incomeLabel,balanceLabel,spendingLabel;
@synthesize mothLabel;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        open = NO;
        UIButton* btn = [UIButton buttonWithType:UIButtonTypeCustom];
        btn.frame = CGRectMake(0, 0, 340,60);
        [btn addTarget:self action:@selector(doSelected) forControlEvents:UIControlEventTouchUpInside];
        self.mothLabel=[[UILabel alloc]initWithFrame:CGRectMake(10, 10,40,40)];
        for (int i=0; i<3; i++) {
            UILabel*incomes=[[UILabel alloc]initWithFrame:CGRectMake(60+i*60+i*16, 5,60,20)];
            incomes.tag=i;
            if (incomes.tag==0) {
                [incomes setText:@"收入："];
            }else if (incomes.tag==1) {
                [incomes setText:@"支出："];
            } else {
                [incomes setText:@"结余："];
            }
            [incomes setBackgroundColor:[UIColor clearColor]];
           // [incomes setBackgroundColor:[UIColor redColor]];
            
            [btn addSubview:incomes];
        }
        self.incomeLabel=[[UILabel alloc]initWithFrame:CGRectMake(60, 35,70,20)];
        self.incomeLabel.backgroundColor = [UIColor clearColor];
        self.incomeLabel.textColor=[UIColor greenColor];
        //[self.incomeLabel setBackgroundColor:[UIColor yellowColor]];
        [btn addSubview:self.incomeLabel];
        self.spendingLabel=[[UILabel alloc]initWithFrame:CGRectMake(136, 35,70,20)];
        self.spendingLabel.backgroundColor = [UIColor clearColor];
        self.spendingLabel.textColor=[UIColor redColor];
        //[self.spendingLabel setBackgroundColor:[UIColor grayColor]];
        [btn addSubview:self.spendingLabel];
        self.balanceLabel=[[UILabel alloc]initWithFrame:CGRectMake(212, 35,70,20)];
        self.balanceLabel.backgroundColor = [UIColor clearColor];
        self.balanceLabel.textColor=[UIColor yellowColor];
        //[self.balanceLabel setBackgroundColor:[UIColor whiteColor]];
        [btn addSubview:self.balanceLabel];
        
            
            
        //self.mothLabel.alpha=0;
        self.mothLabel.backgroundColor = [UIColor clearColor];
        //[self.mothLabel setBackgroundColor:<#(UIColor *)#>];
        [btn addSubview:self.mothLabel];
        [self.mothLabel release];
        [self.incomeLabel release];
        [self.spendingLabel release];
        [self.balanceLabel release];
        [btn setBackgroundImage:[UIImage imageNamed:@"bule.jpg"] forState:UIControlStateNormal];
        [btn setBackgroundImage:[UIImage imageNamed:@"bule.jpg"] forState:UIControlStateHighlighted];
        [self addSubview:btn];
        self.backBtn = btn;

    }
    return self;
}
-(void)doSelected{

    //    [self setImage];
    if (_delegate && [_delegate respondsToSelector:@selector(selectedWith:)]){
     	[_delegate selectedWith:self];
        
    }
}

@end
