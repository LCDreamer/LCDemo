//
//  changeBackground.m
//  NoteTaking
//
//  Created by LC on 13-6-14.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "changeBackground.h"
#import "BIDHomeViewController.h"
#import "BIDnavigationController.h"
#import "BIDBillsViewController.h"
#import "BIDTimeViewController.h"
#import "BIDBudgetingViewController.h"
#import "BIDPushMessageViewController.h"
#import "BIDSetViewController.h"
#import "BIDRememberViewController.h"
#import "BIDAppDelegate.h"
#import "BIDTypeViewController.h"
#import "BIDChartViewController.h"
@interface changeBackground ()

@end

@implementation changeBackground
@synthesize imgName;
@synthesize fenglin;
@synthesize mantuoluo;
@synthesize caodi;
@synthesize muses;
@synthesize zhongguofeng;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)fenglin:(id)sender {
    fenglin = @"fenglin1.jpg";
    
    UIImage *image=[UIImage imageNamed:fenglin] ;
    self.view.backgroundColor = [UIColor colorWithPatternImage: image];
    ((BIDAppDelegate *)[[UIApplication sharedApplication] delegate]).backgroundImg=image;
}

- (IBAction)mantuoluo:(id)sender {
    mantuoluo = @"background1.jpg";
    UIImage *image=[UIImage imageNamed:mantuoluo] ;
    self.view.backgroundColor = [UIColor colorWithPatternImage: image];
    ((BIDAppDelegate *)[[UIApplication sharedApplication] delegate]).backgroundImg=image;
}

- (IBAction)caoyuan:(id)sender {
    caodi = @"caodi.jpg";
    UIImage *image=[UIImage imageNamed:caodi] ;
    self.view.backgroundColor = [UIColor colorWithPatternImage: image];
    ((BIDAppDelegate *)[[UIApplication sharedApplication] delegate]).backgroundImg=image;
}

- (IBAction)muse:(id)sender {
    muses = @"xingkong.jpg";
    UIImage *image=[UIImage imageNamed:muses] ;
    self.view.backgroundColor = [UIColor colorWithPatternImage: image];
    ((BIDAppDelegate *)[[UIApplication sharedApplication] delegate]).backgroundImg=image;
}

- (IBAction)zhongguofeng:(id)sender {
    zhongguofeng = @"zhongguofeng.jpg";
    UIImage *image=[UIImage imageNamed:zhongguofeng] ;
    self.view.backgroundColor = [UIColor colorWithPatternImage: image];
    ((BIDAppDelegate *)[[UIApplication sharedApplication] delegate]).backgroundImg=image;
}
@end
