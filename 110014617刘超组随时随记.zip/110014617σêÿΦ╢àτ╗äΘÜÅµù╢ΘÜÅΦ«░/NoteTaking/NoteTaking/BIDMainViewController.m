//
//  BIDMainViewController.m
//  Message
//
//  Created by 刘超 on 13-4-13.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDMainViewController.h"
#import "BIDHomeViewController.h"
#import "BIDBillsViewController.h"
#import "BIDBudgetViewController.h"
#import "BIDPushMessageViewController.h"
#import "BIDSetViewController.h"
#import "BIDnavigationController.h"
@interface BIDMainViewController ()
-(void)loadViewController;
-(void)loadCustomTabBarView;
@end

@implementation BIDMainViewController
@synthesize imagesArray;
@synthesize imagesHighArray;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.tabBar.hidden=YES;
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{
    self.tabBar.hidden=YES;
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.tabBar.hidden=YES;
}
//初始化各个视图控制器
-(void)loadViewController
{
    BIDHomeViewController*VC1=[[BIDHomeViewController alloc]init];
    BIDnavigationController*homeNave=[[BIDnavigationController alloc]initWithRootViewController:VC1];
    
    UITabBarItem*homeItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemFavorites tag:1];
    VC1.tabBarItem=homeItem;
    
    
    BIDBillsViewController*VC2=[[BIDBillsViewController alloc]init];
//    BIDnavigationController*messageNave=[[BIDnavigationController alloc]initWithRootViewController:VC2];
//    
//    UITabBarItem*messageItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemContacts tag:2];
//    VC2.tabBarItem=messageItem;
    
    
    BIDBudgetViewController*VC3=[[BIDBudgetViewController alloc]init];
    BIDnavigationController*trendsNave=[[BIDnavigationController alloc]initWithRootViewController:VC3];
    
    UITabBarItem*trendsItem=[[UITabBarItem alloc]initWithTitle:@"动态" image:[UIImage imageNamed:@"zhuti1"] tag:3];
    VC3.tabBarItem=trendsItem;
   
    
    BIDPushMessageViewController*VC4=[[BIDPushMessageViewController alloc]init];
    BIDnavigationController*newsNave=[[BIDnavigationController alloc]initWithRootViewController:VC4];
    
    UITabBarItem*newsItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemHistory tag:4];
    VC4.tabBarItem=newsItem;
    
    
    BIDSetViewController*VC5=[[BIDSetViewController alloc]init];
    BIDnavigationController*setNave=[[BIDnavigationController alloc]initWithRootViewController:VC5];
   
    UITabBarItem*setItem=[[UITabBarItem alloc]initWithTabBarSystemItem:UITabBarSystemItemMostRecent tag:5];
    VC5.tabBarItem=setItem;


    
    NSArray*viewcontrollers=@[homeNave,VC2,trendsNave,newsNave,setNave,];
    [self setViewControllers:viewcontrollers animated:YES];
}
//初始化TabBar
-(void)loadCustomTabBarView
{
    _tabBarBG=[[UIImageView alloc]initWithFrame:CGRectMake(0,431,320,49)];
    _tabBarBG.userInteractionEnabled=YES;
    _tabBarBG.image=[UIImage imageNamed:@"blue.jpg"];//filetab-bg.png
    [self.view addSubview:_tabBarBG];
    
    _selectview=[[UIImageView alloc]initWithFrame:CGRectMake(7, 49.0/2-45.0/2, 53, 45)];
    [_tabBarBG addSubview:_selectview];
   self.imagesArray=[[NSArray alloc]initWithObjects:@"shouye.jpg",@"yanjing.jpg",@"yusuan.jpg",@"duanxin.jpg",@"shezhi", nil];
    self.imagesHighArray=[[NSArray alloc]initWithObjects:@"shouye@2x.jpg",@"yanjing@2x",@"yusuan@2x.jpg",@"duanxin@2x.jpg",@"shezhi@2x", nil];
    _selectview.image=[UIImage imageNamed:@"blue.jpg"];
    float coordinateX=0;
    for (int index=0; index<5; index++) {
        UIButton*button=[UIButton buttonWithType:UIButtonTypeRoundedRect];
        button.tag=index;

        NSString*imageName=[NSString stringWithFormat:[imagesArray objectAtIndex:index]];
        NSString*imamgeHigName=[NSString stringWithFormat:[imagesHighArray objectAtIndex:index]];
        [button setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        [button setBackgroundImage:[UIImage imageNamed:imamgeHigName] forState:UIControlStateHighlighted];
        button.frame=CGRectMake(15+coordinateX, 49.0/2-20, 42, 40);
        [_tabBarBG addSubview:button];
        coordinateX+=62;
        [button addTarget:self action:@selector(changeViewController:) forControlEvents:UIControlEventTouchUpInside];
    }
    
}
-(void)changeViewController:(UIButton*)button
{
    self.selectedIndex=button.tag;
    [UIView beginAnimations:nil context:NULL];
    _selectview.frame=CGRectMake(7+button.tag*62, 49.0/2-45.0/2, 53, 45);
    [UIView commitAnimations];
}
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self loadViewController];
    [self loadCustomTabBarView];
   
    
	// Do any additional setup after loading the view.
}
           
@end
