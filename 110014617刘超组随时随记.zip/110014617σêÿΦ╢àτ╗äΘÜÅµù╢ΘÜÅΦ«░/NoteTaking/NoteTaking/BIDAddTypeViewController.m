//
//  BIDAddTypeViewController.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-16.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDAddTypeViewController.h"
#import "BIDAddSubtypeViewController.h"
@interface BIDAddTypeViewController ()
@property(strong,nonatomic)BIDAddSubtypeViewController*addSubtypeView;
@end

@implementation BIDAddTypeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"添加类型";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setUIBarButtonItem];
    self.atype.typeId=0;
    
    self.atype=[[BIDBill alloc]init];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)setUIBarButtonItem{//初始化右边的保存按钮
    UIBarButtonItem*leftItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(nextStep)];
    self.navigationItem.rightBarButtonItem=leftItem;
}
-(void)nextStep{
    BIDAddSubtypeViewController*addSubtypeViewController=[[BIDAddSubtypeViewController alloc]init];
    self.atype.type=self.typeOutlet.text;
     addSubtypeViewController.type=self.atype;
    [self.navigationController pushViewController:addSubtypeViewController animated:YES];
   
}

- (IBAction)selecType:(id)sender {
    if (self.Segment.selectedSegmentIndex==0) {
        self.atype.typeId=0;
    }else{
        self.atype.typeId=1;
    }
}
@end
