//
//  BIDTypeManagement.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDTypeManagement.h"
#import "BIDDatabaseManagement.h"
@implementation BIDTypeManagement
-(id)init{
    self=[super init];
    if (self) {
        BIDDatabaseManagement*Database=[BIDDatabaseManagement sharedDatabaseManagement];
        self.database=Database.database;
    }
    return self;
}
-(BOOL)saveTypeAandSubtype:(BIDType*)atypeAandSubtype
{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (type,subtype) VALUES (?,?)",kTypeTable];
    YesOrNo=[self.database executeUpdate:sql,atypeAandSubtype.type,atypeAandSubtype.subtype];
    
    return YesOrNo;
}
-(NSDictionary*)readTypeAandSubtype{
    NSString*sqlit=[NSString stringWithFormat:@"SELECT distinct type FROM %@ where typeKey='%d'",kTypeTable,1];
    NSMutableDictionary*dic=[[NSMutableDictionary alloc]init];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typeArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDType*aType=[[BIDType alloc]init];
        aType.type=[rs stringForColumn:@"type"];
        
        NSString*subtypesqlit=[NSString stringWithFormat:@"SELECT subtype FROM %@ where type='%@'",kTypeTable,aType.type];
        FMResultSet*rs=[self.database executeQuery:subtypesqlit];
        NSMutableArray*subtypeArray=[[NSMutableArray alloc]init];
        while ([rs next]) {
            BIDType*aSubtype=[[BIDType alloc]init];
            aSubtype.subtype=[rs stringForColumn:@"subtype"];
            [subtypeArray addObject:aSubtype.subtype];
        }
        [dic setObject:subtypeArray forKey:aType.type];
        [typeArray addObject:aType.type];
    }
    return dic;
}

//删除子类型
-(BOOL)deleteSubType:(NSString*)subtype{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"DELETE FROM %@ where subtype='%@'",kTypeTable,subtype];
    YesOrNo=[self.database executeUpdate:sql];
    
    return YesOrNo;
}

//删除类型
-(BOOL)deletetype:(NSString*)atype{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"DELETE FROM %@ where type='%@'",kTypeTable,atype];
    YesOrNo=[self.database executeUpdate:sql];
    
    return YesOrNo;
}
@end
