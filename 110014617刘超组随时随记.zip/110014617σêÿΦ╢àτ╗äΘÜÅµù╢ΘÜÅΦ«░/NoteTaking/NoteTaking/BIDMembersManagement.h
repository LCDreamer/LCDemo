//
//  BIDMembersManagement.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "BIDMembers.h"
@interface BIDMembersManagement : NSObject
@property(strong,nonatomic)FMDatabase*database;
/*-------------增加类和子类-------------------*/

-(BOOL)saveMember:(BIDMembers*)aMember;

/*-------------查类和子类-------------------*/

-(NSArray*)readMember;//读成员
/*-------------修改类型---------------------*/

//修改类型

-(BOOL)modifyMembe:(BIDMembers*)aMembe;

/*-------------删除类型----------------------*/
//删除类型

-(BOOL)deleteMembe:(NSString*)aMembe;

@end
