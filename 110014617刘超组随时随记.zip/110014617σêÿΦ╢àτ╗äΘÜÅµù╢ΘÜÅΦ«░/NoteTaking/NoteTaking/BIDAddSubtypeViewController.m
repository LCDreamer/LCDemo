//
//  BIDAddSubtypeViewController.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-16.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDAddSubtypeViewController.h"
#import "BIDDatabaseManagement.h"
@interface BIDAddSubtypeViewController ()

@end

@implementation BIDAddSubtypeViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"添加子类型";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setUIBarButtonItem];
    NSLog(@"%@",self.type.type);
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)setUIBarButtonItem{//初始化右边的保存按钮
    UIBarButtonItem*leftItem=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemSave target:self action:@selector(save)];
    self.navigationItem.rightBarButtonItem=leftItem;
}
-(void)save{
    self.type.subtype=self.subtypeOutlet.text;
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    [databaseManagement saveTypeAandSubtype:self.type];
    NSLog(@"%@----%@",self.type.type,self.type.subtype);
    UIAlertView *alter = [[UIAlertView alloc] initWithTitle:@"提示" message:@"保存成功" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
    
    [alter show];
}
@end
