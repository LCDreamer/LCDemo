//
//  BIDTypeViewController.m
//  NoteTaking
//  按类查看控制器
//  Created by 刘超 on 13-5-6.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDTypeViewController.h"
#import "BIDDatabaseManagement.h"
#import "BIDRememberViewController.h"
#import "BIDBillsViewController.h"
#import "BIDBillManagement.h"
@interface BIDTypeViewController ()

@end

@implementation BIDTypeViewController
@synthesize tableView = _tableView;
@synthesize headViewArray;
@synthesize typesDic;
@synthesize typesArray;
@synthesize typeKey;
@synthesize typeArry;
@synthesize yearLable;
@synthesize year;
@synthesize newaYear;
@synthesize typeIncomeDic;
@synthesize typeSpendingDic;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.hidesBottomBarWhenPushed=YES;
    }
    return self;
}

- (void)viewDidLoad
{
    NSLog(@"%@",self.navigationController.childViewControllers);

    [super viewDidLoad];
    
     [self selectYear];
    HeadView* headview = [[HeadView alloc] init];
    headview.delegate = self;
  //  self.view.backgroundColor = [UIColor whiteColor];
    [self loadModel];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorColor = [UIColor clearColor];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
//    [self.view setBackgroundColor:[UIColor colorWithPatternImage:[UIImage imageNamed:@"blue.jpg"]]];
   
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self selectYear];
    HeadView* headview = [[HeadView alloc] init];
    headview.delegate = self;
    [self loadModel];
    
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.separatorColor =  [UIColor clearColor];
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:_tableView];
    [_tableView reloadData];
    BIDBillsViewController*tabBarController=(BIDBillsViewController*)self.tabBarController;
    [tabBarController showTabBar];
    
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    self.yearsIncomeOutle.text=[databaseManagement yearsOfIncomeForYear:@"2013"];
    float yearsIncome=[[databaseManagement yearsOfIncomeForYear:self.newaYear]floatValue];
    self.yearsSpendOutlet.text=[databaseManagement yearsOfSpendingForYear:@"2013"];
    float yearsSpend=[[databaseManagement yearsOfSpendingForYear:self.newaYear]floatValue];
    float yearsbalance=yearsIncome-yearsSpend;
    NSString*balance=[NSString stringWithFormat:@"%0.2f",yearsbalance];
    self.yearsbalanceOutle.text=balance;
}

- (void)loadModel{
    _currentRow = -1;
    headViewArray = [[NSMutableArray alloc]init ];
    BIDDatabaseManagement*database=[[BIDDatabaseManagement alloc]init];

    self.typesArray=(NSMutableArray*)[database readTypesForYear:self.newaYear];
    for(int i = 0;i< [self.typesArray count];i++)
	{
		HeadView* headview = [[HeadView alloc] init];
        headview.delegate = self;
		headview.section = i;
        NSString*typekey=[self.typesArray objectAtIndex:i];
        NSString*type=[NSString stringWithFormat:@"%@",typekey];
        NSString*typeIncome=[[self.typeIncomeDic objectForKey:typekey] stringValue];
        NSString*typeSpending=[[self.typeSpendingDic objectForKey:typekey] stringValue];
        float income=[[self.typeIncomeDic objectForKey:typekey] floatValue];
        float spending=[[self.typeSpendingDic objectForKey:typekey] floatValue];
        float balance=income-spending;
        NSString*typebalance=[NSString stringWithFormat:@"%0.2f",balance];
        [headview.incomeLabel setText:typeIncome];
        [headview.spendingLabel setText:typeSpending];
        [headview.balanceLabel setText:typebalance];
        [headview.mothLabel setText:type];
        
		[self.headViewArray addObject:headview];
        
        BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
        self.typeArry=[databaseManagement readTypesForYear:newaYear];
	}
    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    _tableView= nil;
}

#pragma mark - TableViewdelegate&&TableViewdataSource

- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    HeadView* headView = [self.headViewArray objectAtIndex:indexPath.section];
    
    return headView.open?45:0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 60;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 0.1;
}


- (UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return [self.headViewArray objectAtIndex:section];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    HeadView* headView = [self.headViewArray objectAtIndex:section];
    NSUInteger row=[[self.typesDic objectForKey:self.typeKey] count];
    return headView.open?row:0;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [self.headViewArray count];
}



- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSUInteger row=[indexPath row];
    BIDBill*bills=[self.typesArray objectAtIndex:row];
    static NSString *indentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier] ;
        UIButton* backBtn=  [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 340,45)];
        backBtn.tag = 20000;
        [backBtn setBackgroundImage:[UIImage imageNamed:@"Beige.jpg"] forState:UIControlStateHighlighted];
        backBtn.userInteractionEnabled = NO;
        [cell.contentView addSubview:backBtn];
        
        UIImageView*imageView=[[UIImageView alloc]initWithFrame:CGRectMake(10, 6, 33, 33)];
        [imageView setBackgroundColor:[UIColor lightGrayColor]];
        imageView.tag=100;
        [cell.contentView addSubview:imageView];
        UILabel*type=[[UILabel alloc]initWithFrame:CGRectMake(60, 10,100, 25)];
        type.tag=400;
        [type setBackgroundColor:[UIColor whiteColor]];
        [cell.contentView addSubview:type];
        
        UILabel*money=[[UILabel alloc]initWithFrame:CGRectMake(200, 10,100, 25)];
        money.tag=4000;
        [money setBackgroundColor:[UIColor whiteColor]];
        [cell.contentView addSubview:money];
        
        
        UIImageView* line = [[UIImageView alloc]initWithFrame:CGRectMake(0, 44, 340, 1)];
        line.backgroundColor = [UIColor whiteColor];
        [cell.contentView addSubview:line];
        
        
    }
    NSString*amount=[NSString stringWithFormat:@"%0.2f",bills.amount];
    NSString*types=[NSString stringWithFormat:@"%@",bills.subtype];
    UIButton* backBtn = (UIButton*)[cell.contentView viewWithTag:20000];
    HeadView* view = [self.headViewArray objectAtIndex:indexPath.section];
    [backBtn setBackgroundImage:[UIImage imageNamed:@"baise.jpg"] forState:UIControlStateNormal];
    UILabel*type=(UILabel*)[cell.contentView viewWithTag:400];
    [type setText:types];
    UILabel*money=(UILabel*)[cell.contentView viewWithTag:4000];
    [money setText:amount];
    UIImageView*typeImge=(UIImageView*)[cell.contentView viewWithTag:100];
    NSString*imge=[NSString stringWithFormat:@"%d",bills.billType];
    [typeImge setImage:[UIImage imageNamed:imge]];
    if (view.open) {
        if (indexPath.row == _currentRow) {
            [backBtn setBackgroundImage:[UIImage imageNamed:@"baise.jpg"] forState:UIControlStateNormal];
        }
    }
    cell.textLabel.backgroundColor = [UIColor clearColor];
    cell.textLabel.textColor = [UIColor clearColor];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    _currentRow = indexPath.row;
    [_tableView reloadData];
    BIDRememberViewController*rememberViewController=[[BIDRememberViewController alloc]init];
    rememberViewController.yesOrNo=NO;
    rememberViewController.abiil=[self.typesArray objectAtIndex:indexPath.row];
    [self.navigationController pushViewController:rememberViewController animated:YES];
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    NSInteger row=[indexPath row];
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    BIDBill*aBill=[self.typesArray objectAtIndex:row];
    [bill deleteaBill:aBill];
    [self.typesArray removeObjectAtIndex:row];
    [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [self viewWillAppear:NO];
    
}
#pragma mark - HeadViewdelegate
-(void)selectedWith:(HeadView *)view{
    _currentRow = -1;
    if (view.open) {
        for(int i = 0;i<[headViewArray count];i++)
        {
            HeadView *head = [headViewArray objectAtIndex:i];
            head.open = NO;
            [head.backBtn setBackgroundImage:[UIImage imageNamed:@"bule.jpg"] forState:UIControlStateNormal];
        }
        [_tableView reloadData];
        
        return;
    }
    self.typeKey=[self.typeArry objectAtIndex:view.section];
    
    self.typesArray=[self.typesDic objectForKey:self.typeKey];
    _currentSection = view.section;
    [self reset];
    
}
//界面重置
- (void)reset
{
    for(int i = 0;i<[headViewArray count];i++)
    {
        HeadView *head = [headViewArray objectAtIndex:i];
        
        if(head.section == _currentSection)
        {
            head.open = YES;
            [head.backBtn setBackgroundImage:[UIImage imageNamed:@"bule.jpg"] forState:UIControlStateNormal];
            
        }else {
            [head.backBtn setBackgroundImage:[UIImage imageNamed:@"bule.jpg"] forState:UIControlStateNormal];
            
            head.open = NO;
        }
        
    }
    [_tableView reloadData];
}
-(void)selectYear{
    UIView*yearView=[[UIView alloc]initWithFrame:CGRectMake(10, 46, 140, 30)];
    [yearView setBackgroundColor:[UIColor clearColor]];
    UIButton *prevButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [prevButton setImage:[UIImage imageNamed:@"left_arrow.png"] forState:UIControlStateNormal];
    prevButton.frame=CGRectMake(0, 2, 25, 25);
    [prevButton addTarget:self action:@selector(moveCalendarToPreviousYear) forControlEvents:UIControlEventTouchUpInside];
    [yearView addSubview:prevButton];
    
    
    UIButton *nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [nextButton setImage:[UIImage imageNamed:@"right_arrow.png"] forState:UIControlStateNormal];
    nextButton.frame=CGRectMake(115, 2, 25, 25);
    [nextButton addTarget:self action:@selector(moveCalendarToNextYear) forControlEvents:UIControlEventTouchUpInside];
    [yearView addSubview:nextButton];
    
    self.yearLable=[[UILabel alloc]initWithFrame:CGRectMake(30, 2, 80, 25)];
    NSDate* today=[NSDate date];
    NSDateFormatter*catime=[[NSDateFormatter alloc]init];
    [catime setDateStyle:NSDateFormatterMediumStyle];
    [catime setTimeStyle:NSDateFormatterShortStyle];
    [catime setDateFormat:@"YYYY"];
    self.year=[catime stringFromDate:today];
    NSString* thisYear=[NSString stringWithFormat:@"%@年",self.year];
    [self.yearLable setText:thisYear];
    [self.yearLable setTextAlignment:NSTextAlignmentCenter];
    [yearView addSubview:yearLable];
    [self.view addSubview:yearView];
    NSString *newYear = [thisYear substringToIndex:4];
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    self.typesDic=[databaseManagement readTypeOfPaymentForYear:newYear];
    self.newaYear=self.year;
    
    BIDDatabaseManagement*database=[[BIDDatabaseManagement alloc]init];
    self.typeIncomeDic=[database readTypeIncomeForYear:self.year];
    self.typeSpendingDic=[database readTypeSpendingForYear:self.year];
    
}
-(void)moveCalendarToPreviousYear{
    NSInteger years=[self.yearLable.text intValue]-1;
    NSString*newYear=[NSString stringWithFormat:@"%d年",years];
    
    [self.yearLable setText:newYear];
    NSString *newYears = [newYear substringToIndex:4];
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    self.typesDic=[databaseManagement readTypeOfPaymentForYear:newYears];
    self.newaYear=newYears;
    
    BIDDatabaseManagement*database=[[BIDDatabaseManagement alloc]init];
    self.typeIncomeDic=[database readTypeIncomeForYear:self.newaYear];
    self.typeSpendingDic=[database readTypeSpendingForYear:self.newaYear];
    
    self.yearsIncomeOutle.text=[databaseManagement yearsOfIncomeForYear:self.newaYear];
    float yearsIncome=[[databaseManagement yearsOfIncomeForYear:self.newaYear]floatValue];
    self.yearsSpendOutlet.text=[databaseManagement yearsOfSpendingForYear:self.newaYear];
    float yearsSpend=[[databaseManagement yearsOfSpendingForYear:self.newaYear]floatValue];
    float yearsbalance=yearsIncome-yearsSpend;
    NSString*balance=[NSString stringWithFormat:@"%0.2f",yearsbalance];
    self.yearsbalanceOutle.text=balance;
    
    [self loadModel];
    [_tableView reloadData];
}
-(void)moveCalendarToNextYear{
    NSInteger years=[self.yearLable.text intValue]+1;
    NSString*newYear=[NSString stringWithFormat:@"%d年",years];
    [self.yearLable setText:newYear];
    NSString *newYears = [newYear substringToIndex:4];
    BIDDatabaseManagement*databaseManagement=[[BIDDatabaseManagement alloc]init];
    self.typesDic=[databaseManagement readTypeOfPaymentForYear:newYears];
    self.newaYear=newYears;
    
    
    self.yearsIncomeOutle.text=[databaseManagement yearsOfIncomeForYear:self.newaYear];
    float yearsIncome=[[databaseManagement yearsOfIncomeForYear:self.newaYear]floatValue];
    self.yearsSpendOutlet.text=[databaseManagement yearsOfSpendingForYear:self.newaYear];
    float yearsSpend=[[databaseManagement yearsOfSpendingForYear:self.newaYear]floatValue];
    float yearsbalance=yearsIncome-yearsSpend;
    NSString*balance=[NSString stringWithFormat:@"%0.2f",yearsbalance];
    self.yearsbalanceOutle.text=balance;
    
    BIDDatabaseManagement*database=[[BIDDatabaseManagement alloc]init];
    self.typeIncomeDic=[database readTypeIncomeForYear:self.newaYear];
    self.typeSpendingDic=[database readTypeSpendingForYear:self.newaYear];
    
    [self loadModel];
    [_tableView reloadData];
}
@end
