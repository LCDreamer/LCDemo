//
//  BIDHomeViewController.m
//  NoteTaking
//  首页控制器
//  Created by 刘超 on 13-5-5.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDHomeViewController.h"
#import "BIDRememberViewController.h"
#import "BIDBillManagement.h"
#import "changeBackground.h"
#import "BIDAppDelegate.h"
#import "DPMeterView.h"
#import "UIBezierPath+BasicShapes.h"
#import "BIDBillManagement.h"
#import "BIDBudgetManagement.h"
@interface BIDHomeViewController ()

@end

@implementation BIDHomeViewController
@synthesize jiyibi;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title=@"随时随记";
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    NSDate* today=[NSDate date];
    NSDateFormatter*atime=[[NSDateFormatter alloc]init];
    [atime setDateStyle:NSDateFormatterMediumStyle];
    [atime setTimeStyle:NSDateFormatterShortStyle];
    [atime setDateFormat:@"YYYY"];
    NSString*year=[atime stringFromDate:today];
    
    NSDateFormatter*btime=[[NSDateFormatter alloc]init];
    [btime setDateStyle:NSDateFormatterMediumStyle];
    [btime setTimeStyle:NSDateFormatterShortStyle];
    [btime setDateFormat:@"MM"];
    NSString*moth=[btime stringFromDate:today];
    
    NSDateFormatter*ctime=[[NSDateFormatter alloc]init];
    [ctime setDateStyle:NSDateFormatterMediumStyle];
    [ctime setTimeStyle:NSDateFormatterShortStyle];
    [ctime setDateFormat:@"dd"];
    NSString*day=[ctime stringFromDate:today];
    
    
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    float yearsIncome=[bill selectYearIncomeForYear:year];
    NSString*yearsIncomes=[NSString stringWithFormat:@"%0.2f",yearsIncome];
    self.yearsIncomeOutle.text=yearsIncomes;
    float yearsSpend=[bill selectYearSpendingForYear:year];
    NSString*yearsSpendings=[NSString stringWithFormat:@"%0.2f",yearsSpend];
    self.yearsSpendOutlet.text=yearsSpendings;
  
    float mothsIncome=[bill selectMonthsIncomeForYear:year andMonth:moth];
    NSString*mothsIncomes=[NSString stringWithFormat:@"%0.2f",mothsIncome];
    self.mothsIncomeOutle.text=mothsIncomes;
    float mothsSpend=[bill selectMonthsSpendingForYear:year andMonth:moth];
    NSString*mothsSpendings=[NSString stringWithFormat:@"%0.2f",mothsSpend];
    self.mothsSpendOutlet.text=mothsSpendings;
    
    
    float dayIncome=[bill selectDayIncomeForYear:year AndMonth:moth AndDay:day];
    NSString*dayIncomes=[NSString stringWithFormat:@"%0.2f",dayIncome];
    self.dayIncomeOutle.text=dayIncomes;
    float daySpend=[bill selectDaySpendingForYear:year AndMonth:moth AndDay:day];
    NSString*daySpendings=[NSString stringWithFormat:@"%0.2f",daySpend];
    self.daySpendOutlet.text=daySpendings;
    // UIApperance
    [[DPMeterView appearance] setTrackTintColor:[UIColor lightGrayColor]];
    [[DPMeterView appearance] setProgressTintColor:[UIColor darkGrayColor]];
    
    // shape 1 -- Heart
    [self.shape1View setShape:[UIBezierPath heartShape:self.shape1View.frame].CGPath];
    self.shape1View.progressTintColor = [UIColor colorWithRed:189/255.f green:32/255.f blue:49/255.f alpha:1.f];
    // Do any additional setup after loading the view from its nib.
    [self refreshTheAdvanceAmount];//1-self.ratio
    [self updateProgressWithDelta:1-self.ratio animated:YES];
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSDate* today=[NSDate date];
    NSDateFormatter*atime=[[NSDateFormatter alloc]init];
    [atime setDateStyle:NSDateFormatterMediumStyle];
    [atime setTimeStyle:NSDateFormatterShortStyle];
    [atime setDateFormat:@"YYYY"];
    NSString*year=[atime stringFromDate:today];
    
    NSDateFormatter*btime=[[NSDateFormatter alloc]init];
    [btime setDateStyle:NSDateFormatterMediumStyle];
    [btime setTimeStyle:NSDateFormatterShortStyle];
    [btime setDateFormat:@"MM"];
    NSString*moth=[btime stringFromDate:today];
    
    NSDateFormatter*ctime=[[NSDateFormatter alloc]init];
    [ctime setDateStyle:NSDateFormatterMediumStyle];
    [ctime setTimeStyle:NSDateFormatterShortStyle];
    [ctime setDateFormat:@"dd"];
    NSString*day=[ctime stringFromDate:today];
    
    
    BIDBillManagement*bill=[[BIDBillManagement alloc]init];
    float yearsIncome=[bill selectYearIncomeForYear:year];
    NSString*yearsIncomes=[NSString stringWithFormat:@"%0.2f",yearsIncome];
    self.yearsIncomeOutle.text=yearsIncomes;
    float yearsSpend=[bill selectYearSpendingForYear:year];
    NSString*yearsSpendings=[NSString stringWithFormat:@"%0.2f",yearsSpend];
    self.yearsSpendOutlet.text=yearsSpendings;
    
    float mothsIncome=[bill selectMonthsIncomeForYear:year andMonth:moth];
    NSString*mothsIncomes=[NSString stringWithFormat:@"%0.2f",mothsIncome];
    self.mothsIncomeOutle.text=mothsIncomes;
    float mothsSpend=[bill selectMonthsSpendingForYear:year andMonth:moth];
    NSString*mothsSpendings=[NSString stringWithFormat:@"%0.2f",mothsSpend];
    self.mothsSpendOutlet.text=mothsSpendings;
    
    
    float dayIncome=[bill selectDayIncomeForYear:year AndMonth:moth AndDay:day];
    NSString*dayIncomes=[NSString stringWithFormat:@"%0.2f",dayIncome];
    self.dayIncomeOutle.text=dayIncomes;
    float daySpend=[bill selectDaySpendingForYear:year AndMonth:moth AndDay:day];
    NSString*daySpendings=[NSString stringWithFormat:@"%0.2f",daySpend];
    self.daySpendOutlet.text=daySpendings;
    [self refreshTheAdvanceAmount];
    [self updateProgressWithDelta:1-self.ratio animated:YES];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)PushToRememberView:(id)sender {
    BIDRememberViewController*rememberView=[[BIDRememberViewController alloc]init];
    rememberView.yesOrNo=YES;
    [self.navigationController pushViewController:rememberView animated:YES];
}

- (NSArray *)shapeViews
{
    NSMutableArray *shapeViews = [NSMutableArray array];
    
    if (self.shape1View && [self.shape1View isKindOfClass:[DPMeterView class]])
        [shapeViews addObject:self.shape1View];
    return [NSArray arrayWithArray:shapeViews];
}

- (void)updateProgressWithDelta:(CGFloat)delta animated:(BOOL)animated
{
    NSArray *shapeViews = [self shapeViews];
    for (DPMeterView *shapeView in shapeViews) {
        if (delta < 0) {
            [shapeView minus:fabs(delta) animated:animated];
        } else {
            [shapeView add:fabs(delta) animated:animated];
        }
    }
}
-(void)refreshTheAdvanceAmount{
    BIDBudgetManagement*budgetManagement=[[BIDBudgetManagement alloc]init];
    float BudgetSpending=[budgetManagement selectMonthsBudgetSpendingForYear:@"2013" andMonth:@"07"];
    NSString*Budget=[NSString stringWithFormat:@"%0.2f",BudgetSpending];
    BIDBillManagement*billManagement=[[BIDBillManagement alloc]init];
    float MonthsSpending=[billManagement selectMonthsSpendingForYear:@"2013" andMonth:@"07"];
    NSString*Spending=[NSString stringWithFormat:@"%0.2f",MonthsSpending];
    self.ratio=MonthsSpending/BudgetSpending;
    if (BudgetSpending==0) {
        self.ratio=1;
    }
    NSString*available=[NSString stringWithFormat:@"%0.2f",BudgetSpending-MonthsSpending];
    self.allBudgetOutlet.text=Budget;
    self.SpendingOutlet.text=Spending;
    self.availableOutlet.text=available;
}
@end
