//
//  BIDBillManagement.m
//  NoteTaking
//
//  Created by zd2011 on 13-5-24.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBillManagement.h"
#import "BIDDatabaseManagement.h"
@implementation BIDBillManagement
-(id)init{
    self=[super init];
    if (self) {
        BIDDatabaseManagement*Database=[BIDDatabaseManagement sharedDatabaseManagement];
        self.database=Database.database;
    }
    return self;
}
/*---------------增加一笔账单----------------------------------*/

-(BOOL)saveBill:(BIDBill*)abill
{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"INSERT INTO %@ (billType,amount,time,year,moth,type,subtype,members,comment) VALUES (%d,%f,?,?,?,?,?,?,?)",kBillTabel,abill.typeId,abill.amount];
    YesOrNo=[self.database executeUpdate:sql,abill.time,abill.year,abill.moth,abill.type,abill.subtype,abill.membersName,abill.comment];
    
    return YesOrNo;
}
/*---------------删除一笔账单-----------------------------------*/

-(BOOL)deleteaBill:(BIDBill*)aBill{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"DELETE FROM %@ where billId=%d",kBillTabel,aBill.billId];
    YesOrNo=[self.database executeUpdate:sql];
    
    return YesOrNo;
    
}

/*---------------修改一笔帐------------------------------------*/

-(BOOL)modificationaBill:(BIDBill*)aBill{
    BOOL YesOrNo;
    NSString*sql=[NSString stringWithFormat:@"UPDATE %@ set billType=%d,amount=%f,time='%@',year='%@',moth='%@',type='%@',subtype='%@',members='%@',comment='%@' where billId=%d",kBillTabel,aBill.typeId,aBill.amount,aBill.time,aBill.year,aBill.moth,aBill.type,aBill.subtype,aBill.membersName,aBill.comment,aBill.billId];
    YesOrNo=[self.database executeUpdate:sql];
    
    return YesOrNo;
    
}
//查找某年所有记帐的月份
-(NSArray*)selectMonthsForYear:(NSString*)aYear{
    NSString*sqlit=[NSString stringWithFormat:@"select distinct strftime('%%m',time) moths from %@ where strftime('%%Y',time)=='%@'",kBillTabel,aYear];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*scenicsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        
        NSString*moth=[rs stringForColumn:@"moths"];
        [scenicsArray addObject:moth];
    }
    NSLog(@"%d",[scenicsArray count]);
    return scenicsArray;
}
//通过指定年查找每个月的收入，把每个月的收入存放在数组里
-(NSArray*)selectMonthsIncomeForYear:(NSString*)aYear{
    NSArray*MonthsArray=[self selectMonthsForYear:aYear];
    NSMutableArray*MonthsIncomeArray=[[NSMutableArray alloc]init];
    for (int i = 0; i<[MonthsArray count]; i++) {
         NSString*sqlit=[NSString stringWithFormat:@"SELECT moth,SUM(amount) AS MonthIncome FROM %@ where billType=='0' and moth=='%@'",kBillTabel,[MonthsArray objectAtIndex:i]];
        FMResultSet*rs=[self.database executeQuery:sqlit];
        
        while ([rs next]) {
          float MonthIncome=[[rs stringForColumn:@"MonthIncome"]floatValue];
            if (!MonthIncome) {
                MonthIncome=0.00;
            }
            NSString*aMonthIncome=[NSString stringWithFormat:@"%0.2f",MonthIncome];
            [MonthsIncomeArray addObject:aMonthIncome];
        }
    }
    return MonthsIncomeArray;
}
//通过指定年查找每个月的支出，把每个月的收入存放在数组里
-(NSArray*)selectMonthsSpendingForYear:(NSString*)aYear{
    NSArray*MonthsArray=[self selectMonthsForYear:aYear];
    NSMutableArray*MonthsSpendingArray=[[NSMutableArray alloc]init];
    for (int i = 0; i<[MonthsArray count]; i++) {
        NSString*sqlit=[NSString stringWithFormat:@"SELECT moth,SUM(amount) AS MonthIncome FROM %@ where billType=='1' and moth=='%@'",kBillTabel,[MonthsArray objectAtIndex:i]];
        FMResultSet*rs=[self.database executeQuery:sqlit];
        
        while ([rs next]) {
            float MonthIncome=[[rs stringForColumn:@"MonthIncome"] floatValue];
            if (!MonthIncome) {
                MonthIncome=0.00;
            }
            NSString*aMonthIncome=[NSString stringWithFormat:@"%0.2f",MonthIncome];
            [MonthsSpendingArray addObject:aMonthIncome];
        }
    }
    return MonthsSpendingArray;
}
//通过指定年查找每个月的收入，把每个月的收入存放在数组里
-(NSMutableArray*)selectMonthsbillsForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSString*sqlit=[NSString stringWithFormat:@"select*from %@ where strftime('%%Y',time)=='%@' and strftime('%%m',time)=='%@'",kBillTabel,aYear,aMonth];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*BillsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        aBill.billId=[[rs stringForColumn:@"billId"] floatValue];
        aBill.billType=[[rs stringForColumn:@"billType"] intValue];
        aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
        aBill.time=[rs stringForColumn:@"time"];
        aBill.moth=[rs stringForColumn:@"moth"];
        aBill.type=[rs stringForColumn:@"type"];
        aBill.subtype=[rs stringForColumn:@"subtype"];
        aBill.membersName=[rs stringForColumn:@"members"];
        aBill.comment=[rs stringForColumn:@"comment"];
        [BillsArray addObject:aBill];
        
    }
    NSLog(@"%d",[BillsArray count]);
    return BillsArray;
}
//查找某年收入
-(float)selectYearIncomeForYear:(NSString*)aYear{
    NSArray*MonthsIncomeArray=[self selectMonthsIncomeForYear:aYear];
    float yearIncome=0.0;
    for (int i=0; i<[MonthsIncomeArray count]; i++) {
        float aMothIcome=[[MonthsIncomeArray objectAtIndex:i] floatValue];
        yearIncome=yearIncome+aMothIcome;
    }
    return yearIncome;
}
//查找某年的支出
-(float)selectYearSpendingForYear:(NSString*)aYear{
    NSArray*MonthsSpendingArray=[self selectMonthsSpendingForYear:aYear];
    float yearSpending=0.0;
    for (int i=0; i<[MonthsSpendingArray count]; i++) {
        float aMothIcome=[[MonthsSpendingArray objectAtIndex:i] floatValue];
        yearSpending=yearSpending+aMothIcome;
    }
    return yearSpending;
}
//查找某月的收入
-(float)selectMonthIncomeForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSArray*MonthsIncomeArray=[self selectMonthsIncomeForYear:aYear];
    NSUInteger row=[aMonth integerValue];
    float amonthsIncome=[[MonthsIncomeArray objectAtIndex:row] floatValue];
    return amonthsIncome;
}
//查找某月的支出
-(float)selectMonthSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSArray*MonthsSpendingArray=[self selectMonthsSpendingForYear:aYear];
    NSUInteger row=[aMonth integerValue];
    float amonthsSpending=[[MonthsSpendingArray objectAtIndex:row] floatValue];
    return amonthsSpending;
}
//查找某天的收入
-(float)selectDayIncomeForYear:(NSString*)aYear AndMonth:(NSString*)aMoth AndDay:(NSString*)aDay
{
    NSString*sqlit=[NSString stringWithFormat:@"select SUM(amount) AS aDayIncome from %@ where strftime('%%Y',time)=='%@' and strftime('%%m',time)=='%@'and strftime('%%d',time)=='%@'and billType=='0'",kBillTabel,aYear,aMoth,aDay];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float aDayIncome =0.0;
    while ([rs next]) {
        aDayIncome=[[rs stringForColumn:@"aDayIncome"] floatValue];
    }
    return aDayIncome;
}

//查找某天的支出
-(float)selectDaySpendingForYear:(NSString*)aYear AndMonth:(NSString*)aMoth AndDay:(NSString*)aDay
{
    NSString*sqlit=[NSString stringWithFormat:@"select SUM(amount) AS aDaySpending from %@ where strftime('%%Y',time)=='%@' and strftime('%%m',time)=='%@'and strftime('%%d',time)=='%@'and billType=='1'",kBillTabel,aYear,aMoth,aDay];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float aDaySpending =0.0;
    while ([rs next]) {
        aDaySpending=[[rs stringForColumn:@"aDaySpending"] floatValue];
    }
    return aDaySpending;
}

//查找某年所有记帐的类型
-(NSArray*)selectTypesForYear:(NSString*)aYear{
    NSString*sqlit=[NSString stringWithFormat:@"select distinct type from %@ where strftime('%%Y',time)=='%@'",kBillTabel,aYear];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typesArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        
        NSString*type=[rs stringForColumn:@"type"];
        [typesArray addObject:type];
    }
    NSLog(@"%d",[typesArray count]);
    return typesArray;
}
//查找某年（支持或收入）所有记帐的类型
-(NSArray*)selectTypesForYear:(NSString*)aYear andBillType:(NSUInteger)atype{
    NSString*sqlit=[NSString stringWithFormat:@"select distinct type from %@ where strftime('%%Y',time)=='%@' and billType=='%d'",kBillTabel,aYear,atype];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*typesArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        
        NSString*type=[rs stringForColumn:@"type"];
        [typesArray addObject:type];
    }
    NSLog(@"%d",[typesArray count]);
    return typesArray;
}
//查找某种类型的收入

-(NSArray*)selectTypesIncomeForYear:(NSString*)aYear{
    NSArray*typesArray=[self selectTypesForYear:aYear];
    NSMutableArray*typesIncomeArray=[[NSMutableArray alloc]init];
    for (int i = 0; i<[typesArray count]; i++) {
        NSString*sqlit=[NSString stringWithFormat:@"SELECT moth,SUM(amount) AS typeIncome FROM %@ where billType=='0' and type=='%@'",kBillTabel,[typesArray objectAtIndex:i]];
        FMResultSet*rs=[self.database executeQuery:sqlit];
        
        while ([rs next]) {
            float typeIncome=[[rs stringForColumn:@"typeIncome"]floatValue];
            if (!typeIncome) {
                typeIncome=0.00;
            }
            NSString*atypeIncome=[NSString stringWithFormat:@"%0.2f",typeIncome];
            [typesIncomeArray addObject:atypeIncome];
        }
    }
    return typesIncomeArray;
    
}

//查找某种类型的支出
-(NSArray*)selectTypesSpendingForYear:(NSString*)aYear{
    NSArray*typesArray=[self selectTypesForYear:aYear];
    NSMutableArray*typesSpendingArray=[[NSMutableArray alloc]init];
    for (int i = 0; i<[typesArray count]; i++) {
        NSString*sqlit=[NSString stringWithFormat:@"SELECT moth,SUM(amount) AS typeSpending FROM %@ where billType=='1' and type=='%@'",kBillTabel,[typesArray objectAtIndex:i]];
        FMResultSet*rs=[self.database executeQuery:sqlit];
        
        while ([rs next]) {
            float typeSpending=[[rs stringForColumn:@"typeSpending"]floatValue];
            if (!typeSpending) {
                typeSpending=0.00;
            }
            NSString*atypeSpending=[NSString stringWithFormat:@"%0.2f",typeSpending];
            [typesSpendingArray addObject:atypeSpending];
        }
    }
    return typesSpendingArray;
}

//通过指定年查找每个月的收入，把每个月的收入存放在数组里
-(NSArray*)selectTypesbillsForYear:(NSString*)aYear andBillType:(NSUInteger)atype{
    NSString*sqlit=[NSString stringWithFormat:@"select*from %@ where strftime('%%Y',time)=='%@' and billType=='%d'",kBillTabel,aYear,atype];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*BillsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        aBill.billType=[[rs stringForColumn:@"billType"] intValue];
        aBill.amount=[[rs stringForColumn:@"amount"] floatValue];
        aBill.time=[rs dateForColumn:@"time"];
        aBill.moth=[rs stringForColumn:@"moth"];
        aBill.type=[rs stringForColumn:@"type"];
        aBill.subtype=[rs stringForColumn:@"subtype"];
        aBill.membersName=[rs stringForColumn:@"members"];
        aBill.comment=[rs stringForColumn:@"comment"];
        [BillsArray addObject:aBill];
        
    }
    NSLog(@"%d",[BillsArray count]);
    return BillsArray;
}

//通过年查找收入支出中每种类型的消费
-(NSArray*)selectTypesStatisticsForYear:(NSString*)aYear andBillType:(NSUInteger)atype{
    NSString*sqlit=[NSString stringWithFormat:@"select type ,sum(amount) AS sumAmount from %@ where strftime('%%Y',time)=='%@' and billType=='%d' group by type",kBillTabel,aYear,atype];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*BillsArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        BIDBill*aBill=[[BIDBill alloc]init];
        aBill.amount=[[rs stringForColumn:@"sumAmount"] floatValue];
        aBill.type=[rs stringForColumn:@"type"];
        [BillsArray addObject:aBill];
    }
    NSLog(@"%d",[BillsArray count]);
    return BillsArray;
    
}
//查找某月的收入，用于主页面刷新
-(float)selectMonthsIncomeForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSString*sqlit=[NSString stringWithFormat:@"select SUM(amount) AS aDayIncome from %@ where strftime('%%Y',time)=='%@' and strftime('%%m',time)=='%@' and billType=='0'",kBillTabel,aYear,aMonth];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float aDayIncome =0.0;
    while ([rs next]) {
        aDayIncome=[[rs stringForColumn:@"aDayIncome"] floatValue];
    }
    return aDayIncome;
}

//查找某月的支出,用于主页面刷新
-(float)selectMonthsSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth{
    NSString*sqlit=[NSString stringWithFormat:@"select SUM(amount) AS aDayIncome from %@ where strftime('%%Y',time)=='%@' and strftime('%%m',time)=='%@' and billType=='1'",kBillTabel,aYear,aMonth];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float aDayIncome =0.0;
    while ([rs next]) {
        aDayIncome=[[rs stringForColumn:@"aDayIncome"] floatValue];
    }
    return aDayIncome;
}
//查找某月某种类型的支出,用于预算刷新
-(float)selectTypeSpendingForYear:(NSString*)aYear andMonth:(NSString*)aMonth andType:(NSString*)type
{
    NSString*sqlit=[NSString stringWithFormat:@"select SUM(amount) AS aDayIncome from %@ where strftime('%%Y',time)=='%@' and strftime('%%m',time)=='%@' and billType=='1' and type=='%@'",kBillTabel,aYear,aMonth,type];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    float aTypeIncome =0.0;
    while ([rs next]) {
        aTypeIncome=[[rs stringForColumn:@"aDayIncome"] floatValue];
    }
    return aTypeIncome;
}
//查找某年所有记帐的类型
-(NSArray*)selectMembersNamesForYear:(NSString*)aYear{
    NSString*sqlit=[NSString stringWithFormat:@"select distinct members from %@ where strftime('%%Y',time)=='%@'",kBillTabel,aYear];
    FMResultSet*rs=[self.database executeQuery:sqlit];
    NSMutableArray*membersArray=[[NSMutableArray alloc]init];
    while ([rs next]) {
        
        NSString*type=[rs stringForColumn:@"members"];
        [membersArray addObject:type];
    }
    NSLog(@"%d",[membersArray count]);
    return membersArray;
}
//查找某种类的收入
-(NSArray*)selectMembersIncomeForYear:(NSString*)aYear{
    NSArray*MembersNamesArray=[self selectMembersNamesForYear:aYear];
    NSMutableArray*MembersIncomeArray=[[NSMutableArray alloc]init];
    for (int i = 0; i<[MembersNamesArray count]; i++) {
        NSString*sqlit=[NSString stringWithFormat:@"SELECT moth,SUM(amount) AS typeIncome FROM %@ where billType=='0' and members=='%@'",kBillTabel,[MembersNamesArray objectAtIndex:i]];
        FMResultSet*rs=[self.database executeQuery:sqlit];
        
        while ([rs next]) {
            float MemberIncome=[[rs stringForColumn:@"typeIncome"]floatValue];
            if (!MemberIncome) {
                MemberIncome=0.00;
            }
            NSString*aMemberIncome=[NSString stringWithFormat:@"%0.2f",MemberIncome];
            [MembersIncomeArray addObject:aMemberIncome];
        }
    }
    return MembersIncomeArray;
}
//查找所有成员的支出
-(NSArray*)selectMembersSpendingForYear:(NSString*)aYear{
    NSArray*membersArray=[self selectMembersNamesForYear:aYear];
    NSMutableArray*membersSpendingArray=[[NSMutableArray alloc]init];
    for (int i = 0; i<[membersArray count]; i++) {
        NSString*sqlit=[NSString stringWithFormat:@"SELECT moth,SUM(amount) AS typeSpending FROM %@ where billType=='1' and members=='%@'",kBillTabel,[membersArray objectAtIndex:i]];
        FMResultSet*rs=[self.database executeQuery:sqlit];
        
        while ([rs next]) {
            float membersSpending=[[rs stringForColumn:@"typeSpending"]floatValue];
            if (!membersSpending) {
                membersSpending=0.00;
            }
            NSString*atypeSpending=[NSString stringWithFormat:@"%0.2f",membersSpending];
            [membersSpendingArray addObject:atypeSpending];
        }
    }
    return membersSpendingArray;
}
@end
