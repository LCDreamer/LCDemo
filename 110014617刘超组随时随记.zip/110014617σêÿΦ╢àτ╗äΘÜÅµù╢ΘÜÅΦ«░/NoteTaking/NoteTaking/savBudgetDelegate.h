//
//  savBudgetDelegate.h
//  FPNumberPadView
//
//  Created by LiuChao on 13-6-7.
//  Copyright (c) 2013年 Fabrizio Prosperi. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol savBudgetDelegate <NSObject>
@optional
-(BOOL)saveBudet:(int)index andTitle:(NSString*)title;
-(void)accordingspendingModule;//显示支出入模块
-(void)accordingIncomeModule;//显示收入模块
@end
