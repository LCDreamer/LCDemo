//
//  BIDDetailBillViewController.m
//  NoteTaking
//
//  Created by LiuChao on 13-5-17.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDDetailBillViewController.h"
#import "BIDBillsViewController.h"
#import "BIDnavigationController.h"
@interface BIDDetailBillViewController ()

@end

@implementation BIDDetailBillViewController
@synthesize _tabBar;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       self.title=@"详细帐单";
          }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
   BIDBillsViewController*tabBarController=(BIDBillsViewController*)self.tabBarController;
   [tabBarController hiddentTabBar];
    [self.view setBackgroundColor:[UIColor darkGrayColor]];
   
    // Do any additional setup after loading the view from its nib.
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
