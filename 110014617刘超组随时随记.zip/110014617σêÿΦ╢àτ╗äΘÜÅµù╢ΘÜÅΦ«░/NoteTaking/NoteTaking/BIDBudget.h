//
//  BIDBudget.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-23.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BIDBudget : NSObject
@property(assign,nonatomic)NSUInteger budgeId;//账单Id
@property(assign,nonatomic)float budgeAmount;// 预算金额
@property(assign,nonatomic)float restAmount;
@property(strong,nonatomic)NSData*budgeTime;//预算时间
@property(assign,nonatomic)NSUInteger typeId;//账单Id
@property(assign,nonatomic)NSUInteger subtypeId;// 账单类型 Id
@property(strong,nonatomic)NSString*type;//类型
@property(strong,nonatomic)NSString*subtype;//子类型
@end
