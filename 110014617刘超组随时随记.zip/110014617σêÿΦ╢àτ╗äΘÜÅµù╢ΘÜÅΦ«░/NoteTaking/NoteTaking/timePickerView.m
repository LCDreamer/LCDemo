//
//  timePickerView.m
//  timePicker
//
//  Created by LiuChao on 13-5-13.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "timePickerView.h"
#define kDuration 0.3
@implementation timePickerView
@synthesize selectedDate;
- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id)initWithTitle:(NSString *)title delegate:(id)aDelegate
{
    
    
    self = [[[NSBundle mainBundle] loadNibNamed:@"timePickerView" owner:self options:nil] objectAtIndex:0];
    if (self) {
        self.timeDelegate = aDelegate;
        self.titleLabel.text = title;
    }
    return self;
}
- (void)showInView:(UIView *) view//初始化控制器
{
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromTop;
    [self setAlpha:1.0f];
    [self.layer addAnimation:animation forKey:@"DDLocateView"];
    
    self.frame = CGRectMake(0, view.frame.size.height - self.frame.size.height, self.frame.size.width, self.frame.size.height);
    
    [view addSubview:self];
}

- (IBAction)choose:(id)sender {
    CATransition *animation = [CATransition  animation];
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    [self setAlpha:0.0f];
    [self.layer addAnimation:animation forKey:@"timePickerView"];
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
    self.selectedDate=[_timePickerOutlet date];
    NSString*time=[NSString stringWithFormat:@"%@",self.selectedDate];
    if (self.timeDelegate) {
        [self.timeDelegate timeSelection:time];
    }
    NSLog(@"%@",time);
}

- (IBAction)sender:(id)sender {
    CATransition *animation = [CATransition  animation];
    animation.delegate = self;
    animation.duration = kDuration;
    animation.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    animation.type = kCATransitionPush;
    animation.subtype = kCATransitionFromBottom;
    [self setAlpha:0.0f];
    if (self.timeDelegate) {
       [self.timeDelegate isOpenTimePikerView];
    }
    
    [self.layer addAnimation:animation forKey:@"timePickerView"];
    [self performSelector:@selector(removeFromSuperview) withObject:nil afterDelay:kDuration];
}
@end
