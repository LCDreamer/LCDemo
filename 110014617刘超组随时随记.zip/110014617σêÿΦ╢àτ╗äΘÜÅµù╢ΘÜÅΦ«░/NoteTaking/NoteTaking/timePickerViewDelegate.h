//
//  timePickerViewDelegate.h
//  timePicker
//
//  Created by LiuChao on 13-5-13.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol timePickerViewDelegate <NSObject>
@optional
-(void)timeSelection:(NSString*)time;
-(void)isOpenTimePikerView;
@end
