//
//  ViewController.h
//  KuaiPanOpenAPIDemo
//
//  Created by Jinbo He on 12-7-12.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <KuaiPanOpenAPI/KuaiPanOpenAPI.h>
#define KMyDatabaseDatabase @"Database.sqlite"
@interface ViewController : UIViewController {

    KPAuthController                    *authController;    // 授权及注册视图
    
    KPGetUserInfoOperation              *_getUserInfoOp;     // 获取用户信息操作
    KPCreateFolderOperation             *_createFolderOp;    // 创建文件夹操作
    KPGetDirectoryOperation             *_getDirectoryOp;    // 获取文件（夹）信息操作
    KPUploadFileOperation               *_uploadFileOp;      // 上传文件
    KPDownloadFileOperation             *_downloadFileOp;    // 下载文件
    KPDeleteOperation                   *_deleteOp;          // 删除文件（夹）操作
    KPMoveOperation                     *_moveOp;            // 移动文件（夹）操作
    KPCopyOperation                     *_copyOp;            // 复制文件（夹）操作
    KPGetShareLinkOperation             *_shareFileOp;       // 分享文件链接
    KPCopyRefOperation                  *_copyRefFileOp;     // 复制引用
    KPThumbnailOperation                *_thumbnailOp;       // 获取缩略图
    KPDocumentConvertOperation          *_documentConvertOp; // 文档转换
    KPGetFileHistoryOperation           *_historyOP;         // 文件的历史版本
    
    IBOutlet UITextView                 *_textLog;
    IBOutlet UIActivityIndicatorView    *_activity;
    IBOutlet UIProgressView             *_progress;
    IBOutlet UIImageView                *_imageView;
}

@end


@interface ViewController (Action)

- (IBAction)doAuthorize:(id)sender;
- (IBAction)doGetUserInfo:(id)sender;
- (IBAction)doCreateFolder:(id)sender;
- (IBAction)doGetDirectoryInfo:(id)sender;
- (IBAction)doUploadFile:(id)sender;
- (IBAction)doDownloadFile:(id)sender;
- (IBAction)doDeleteFile:(id)sender;
- (IBAction)doDeleteFolder:(id)sender;
- (IBAction)doMoveFile:(id)sender;
- (IBAction)doMoveFolder:(id)sender;
- (IBAction)doCopyFile:(id)sender;
- (IBAction)doCopyFolder:(id)sender;
- (IBAction)doShareFile:(id)sender;
- (IBAction)doCopyRefFile:(id)sender;
- (IBAction)doCopyRefFolder:(id)sender;
- (IBAction)doThumbnail:(id)sender;
- (IBAction)doDocumentView:(id)sender;
- (IBAction)doFileHistory:(id)sender;

- (IBAction)doExit:(id)sender;

@end


@interface ViewController (Operations)<KPOperationDelegate>

@end
