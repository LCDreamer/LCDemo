//
//  BIDMembers.h
//  NoteTaking
//
//  Created by zd2011 on 13-5-23.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BIDMembers : NSObject
@property(assign,nonatomic)NSUInteger membersId;//成员Id;
@property(strong,nonatomic)NSString*membersName;//成员名
@end
