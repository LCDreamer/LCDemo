//
//  BIDRememberViewController.h
//  NoteTaking
//
//  Created by LiuChao on 13-5-9.
//  Copyright (c) 2013年 刘超. All rights reserved.
//

#import "BIDBaseViewController.h"
#import "SINavigationMenuView.h"
#import "SIMenuTable.h"
#import "ZenKeyboardView.h"
#import "pickerView.h"
#import "timePickerViewDelegate.h"
#import "BIDDatabaseManagement.h"
#import "savBudgetDelegate.h"
@interface BIDRememberViewController : BIDBaseViewController<SINavigationMenuDelegate,ZenKeyboardViewDelegate,pickerViewDelegate,timePickerViewDelegate,UITextFieldDelegate,UITextViewDelegate,savBudgetDelegate>
@property(assign,nonatomic)BOOL yesOrNo;
@property (weak, nonatomic) IBOutlet UILabel *typeNameOutlet;//类型输出口
@property (weak, nonatomic) IBOutlet UIImageView *templateTypeImageOutlet;//类型图片输出口
@property (weak, nonatomic) IBOutlet UITextField *amountOutlet;//金额输出口
@property (nonatomic, strong) ZenKeyboardView *keyboardView;//键盘类指针
- (IBAction)SaveTheBill:(id)sender;
- (IBAction)toWriteaBill:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *typeOutlet;//金钱输出口
@property (weak, nonatomic) IBOutlet UITextField *membersOutlet;
- (IBAction)showTypePikerView:(id)sender;
- (IBAction)showMembersPikerView:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *timeOutlet;
- (IBAction)showTimePikerView:(id)sender;
@property (weak, nonatomic) IBOutlet UITextView *commentOutlet;
@property (weak, nonatomic) IBOutlet UIButton *saveBillOutlet;//保存按钮输出口
@property (weak, nonatomic) IBOutlet UIButton *toWriteOutlet;
@property(assign,nonatomic)BOOL isOpenTypePiker;
@property(assign,nonatomic)BOOL isOpenMenberPiker;
@property(assign,nonatomic)BOOL isOpenTimePiker;
@property(assign,nonatomic)NSUInteger typeId;
@property(strong,nonatomic)BIDBill*abiil;
@end
