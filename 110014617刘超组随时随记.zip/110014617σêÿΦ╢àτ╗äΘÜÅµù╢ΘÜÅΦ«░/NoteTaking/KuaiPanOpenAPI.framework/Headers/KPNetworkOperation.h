//
//  KPNetworkOperation.h
//  KuaiPanOpenAPI
//
//  Created by Jinbo He on 12-7-13.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPOperation.h"

@interface KPNetworkOperation : KPOperation<NSURLConnectionDelegate> {
    
    NSURLConnection *_connection;
    NSMutableData   *_receiveData;
}

@end
