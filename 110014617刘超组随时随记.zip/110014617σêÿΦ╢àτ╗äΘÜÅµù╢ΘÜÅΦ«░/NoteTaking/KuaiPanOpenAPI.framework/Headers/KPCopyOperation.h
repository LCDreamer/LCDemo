//
//  KPCopyOperation.h
//  KuaiPanOpenAPI
//
//  Created by tabu on 12-7-19.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPNetworkOperation.h"

@interface KPCopyOperation : KPNetworkOperation

@end
