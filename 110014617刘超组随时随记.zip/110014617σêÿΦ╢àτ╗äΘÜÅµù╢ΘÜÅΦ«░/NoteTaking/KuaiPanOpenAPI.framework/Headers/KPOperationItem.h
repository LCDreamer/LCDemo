//
//  KPOperationItem.h
//  KuaiPanOpenAPI
//
//  Created by Jinbo He on 12-7-13.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class KPConsumer;

@interface KPOperationItem : NSObject {
    KPConsumer  *consumer;
}

@property(nonatomic, retain) KPConsumer  *consumer;

@end
