//
//  KPMoveOperationItem.h
//  KuaiPanOpenAPI
//
//  Created by tabu on 12-7-18.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPFolderOperationItem.h"

@interface KPMoveOperationItem : KPFolderOperationItem
{
    NSString        *fromPath;
    NSString        *toPath;
}

@property(nonatomic, retain) NSString       *fromPath;
@property(nonatomic, retain) NSString       *toPath;

@end
