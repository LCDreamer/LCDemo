//
//  KPDeleteOperation.h
//  KuaiPanOpenAPI
//
//  Created by Jinbo He on 12-7-18.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPNetworkOperation.h"

@interface KPDeleteOperation : KPNetworkOperation

@end
