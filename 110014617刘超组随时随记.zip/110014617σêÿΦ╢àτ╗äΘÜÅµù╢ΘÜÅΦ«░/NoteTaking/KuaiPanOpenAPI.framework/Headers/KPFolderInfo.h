//
//  KPFolderInfo.h
//  KuaiPanOpenAPI
//
//  Created by Jinbo He on 12-7-17.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "KPFolderOperationItem.h"

@interface KPFolderInfo : KPFolderOperationItem {
    NSString        *fileID;
}

@property(nonatomic, retain) NSString        *fileID;

@end
