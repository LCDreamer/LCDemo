//
//  KPFolderOperationItem.h
//  KuaiPanOpenAPI
//
//  Created by Jinbo He on 12-7-17.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPOperationItem.h"

@interface KPFolderOperationItem : KPOperationItem {
    NSString        *root;
    NSString        *path;
}

@property(nonatomic, retain) NSString        *root;
@property(nonatomic, retain) NSString        *path;

@end
