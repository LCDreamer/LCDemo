//
//  KPGetShareLinkOperationItem.h
//  KuaiPanOpenAPI
//
//  Created by tabu on 12-7-19.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPFolderOperationItem.h"

@interface KPGetShareLinkOperationItem : KPFolderOperationItem
{
    NSString        *name;
    NSString        *accessCode;
}

@property(nonatomic, retain) NSString       *name;
@property(nonatomic, retain) NSString       *accessCode;

@end
