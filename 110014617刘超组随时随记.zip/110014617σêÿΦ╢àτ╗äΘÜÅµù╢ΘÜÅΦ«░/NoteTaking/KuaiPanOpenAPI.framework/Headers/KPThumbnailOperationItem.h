//
//  KPThumbnailOperationItem.h
//  KuaiPanOpenAPI
//
//  Created by tabu on 12-7-19.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPFolderOperationItem.h"

@interface KPThumbnailOperationItem : KPFolderOperationItem
{
    NSInteger       width;
    NSInteger       height;
}

@property(nonatomic, assign) NSInteger      width;
@property(nonatomic, assign) NSInteger      height;

@end
