//
//  KPUploadFileOperation.h
//  KuaiPanOpenAPI
//
//  Created by Jinbo He on 12-7-17.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPNetworkOperation.h"

@interface KPUploadFileOperation : KPNetworkOperation

@end
