//
//  KPMoveOperation.h
//  KuaiPanOpenAPI
//
//  Created by tabu on 12-7-18.
//  Copyright (c) 2012年 KuaiPan. All rights reserved.
//

#import "KPNetworkOperation.h"

@interface KPMoveOperation : KPNetworkOperation

@end
